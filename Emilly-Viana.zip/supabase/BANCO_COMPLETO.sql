-- =====================================================================
-- Sistema de Agendamento — schema inicial
-- Rode este arquivo no SQL Editor do seu projeto Supabase.
-- =====================================================================

-- ---------- ENUMS ----------
do $$ begin
  create type public.app_role as enum ('admin', 'staff', 'client');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.appointment_status as enum ('pending', 'confirmed', 'cancelled', 'done');
exception when duplicate_object then null; end $$;

-- ---------- PROFILES ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  avatar_url text,
  created_at timestamptz not null default now()
);

grant select, insert, update on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;

drop policy if exists "own profile select" on public.profiles;
create policy "own profile select" on public.profiles
  for select to authenticated using (auth.uid() = id);

drop policy if exists "own profile insert" on public.profiles;
create policy "own profile insert" on public.profiles
  for insert to authenticated with check (auth.uid() = id);

drop policy if exists "own profile update" on public.profiles;
create policy "own profile update" on public.profiles
  for update to authenticated using (auth.uid() = id);

-- cria profile automaticamente no signup
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, new.raw_user_meta_data->>'full_name')
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------- USER ROLES ----------
create table if not exists public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role app_role not null,
  unique (user_id, role)
);

grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;

drop policy if exists "read own roles" on public.user_roles;
create policy "read own roles" on public.user_roles
  for select to authenticated using (auth.uid() = user_id);

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

-- ---------- PROFISSIONAIS ----------
create table if not exists public.professionals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  name text not null,
  role_title text,
  avatar_url text,
  bio text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

grant select on public.professionals to anon, authenticated;
grant all on public.professionals to service_role;
alter table public.professionals enable row level security;

drop policy if exists "professionals public read" on public.professionals;
create policy "professionals public read" on public.professionals
  for select to anon, authenticated using (active);

drop policy if exists "professionals admin write" on public.professionals;
create policy "professionals admin write" on public.professionals
  for all to authenticated using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

-- ---------- SERVIÇOS ----------
create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  duration_minutes int not null default 60,
  price_cents int not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

grant select on public.services to anon, authenticated;
grant all on public.services to service_role;
alter table public.services enable row level security;

drop policy if exists "services public read" on public.services;
create policy "services public read" on public.services
  for select to anon, authenticated using (active);

drop policy if exists "services admin write" on public.services;
create policy "services admin write" on public.services
  for all to authenticated using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

-- quais serviços cada profissional atende
create table if not exists public.professional_services (
  professional_id uuid not null references public.professionals(id) on delete cascade,
  service_id uuid not null references public.services(id) on delete cascade,
  primary key (professional_id, service_id)
);

grant select on public.professional_services to anon, authenticated;
grant all on public.professional_services to service_role;
alter table public.professional_services enable row level security;

drop policy if exists "prof services public read" on public.professional_services;
create policy "prof services public read" on public.professional_services
  for select to anon, authenticated using (true);

-- ---------- HORÁRIOS DE TRABALHO ----------
create table if not exists public.availability (
  id uuid primary key default gen_random_uuid(),
  professional_id uuid not null references public.professionals(id) on delete cascade,
  weekday int not null check (weekday between 0 and 6), -- 0 = domingo
  start_time time not null,
  end_time time not null,
  check (end_time > start_time)
);

grant select on public.availability to anon, authenticated;
grant all on public.availability to service_role;
alter table public.availability enable row level security;

drop policy if exists "availability public read" on public.availability;
create policy "availability public read" on public.availability
  for select to anon, authenticated using (true);

-- bloqueios / folgas pontuais
create table if not exists public.time_off (
  id uuid primary key default gen_random_uuid(),
  professional_id uuid not null references public.professionals(id) on delete cascade,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  reason text,
  check (ends_at > starts_at)
);

grant select on public.time_off to anon, authenticated;
grant all on public.time_off to service_role;
alter table public.time_off enable row level security;

drop policy if exists "time off public read" on public.time_off;
create policy "time off public read" on public.time_off
  for select to anon, authenticated using (true);

-- ---------- AGENDAMENTOS ----------
create table if not exists public.appointments (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references auth.users(id) on delete cascade,
  professional_id uuid not null references public.professionals(id) on delete restrict,
  service_id uuid not null references public.services(id) on delete restrict,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  status appointment_status not null default 'pending',
  notes text,
  created_at timestamptz not null default now(),
  check (ends_at > starts_at)
);

create index if not exists appointments_prof_time_idx
  on public.appointments (professional_id, starts_at);
create index if not exists appointments_client_idx
  on public.appointments (client_id, starts_at);

grant select, insert, update, delete on public.appointments to authenticated;
grant all on public.appointments to service_role;
alter table public.appointments enable row level security;

drop policy if exists "client reads own appointments" on public.appointments;
create policy "client reads own appointments" on public.appointments
  for select to authenticated
  using (client_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "client creates own appointments" on public.appointments;
create policy "client creates own appointments" on public.appointments
  for insert to authenticated with check (client_id = auth.uid());

drop policy if exists "client updates own appointments" on public.appointments;
create policy "client updates own appointments" on public.appointments
  for update to authenticated
  using (client_id = auth.uid() or public.has_role(auth.uid(), 'admin'))
  with check (client_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "client deletes own appointments" on public.appointments;
create policy "client deletes own appointments" on public.appointments
  for delete to authenticated
  using (client_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

-- evita dois agendamentos ativos sobrepostos para o mesmo profissional
create or replace function public.prevent_overlap()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.status in ('pending', 'confirmed') and exists (
    select 1 from public.appointments a
    where a.professional_id = new.professional_id
      and a.id <> coalesce(new.id, gen_random_uuid())
      and a.status in ('pending', 'confirmed')
      and a.starts_at < new.ends_at
      and a.ends_at > new.starts_at
  ) then
    raise exception 'Horário indisponível para este profissional';
  end if;
  return new;
end $$;

drop trigger if exists appointments_no_overlap on public.appointments;
create trigger appointments_no_overlap
  before insert or update on public.appointments
  for each row execute function public.prevent_overlap();

-- ---------- DADOS DE EXEMPLO ----------
insert into public.services (name, description, duration_minutes, price_cents)
select * from (values
  ('Corte de cabelo', 'Corte masculino ou feminino', 45, 8000),
  ('Coloração',       'Coloração completa',          120, 22000),
  ('Manicure',        'Cuidado completo das mãos',   40, 6000),
  ('Barba',           'Aparo e desenho de barba',    30, 5000)
) as t(name, description, duration_minutes, price_cents)
where not exists (select 1 from public.services);

insert into public.professionals (name, role_title)
select * from (values
  ('Ana Souza',    'Cabeleireira'),
  ('Bruno Lima',   'Barbeiro'),
  ('Carla Mendes', 'Manicure')
) as t(name, role_title)
where not exists (select 1 from public.professionals);

-- horário padrão: seg-sáb, 09:00–18:00 para todos os profissionais
insert into public.availability (professional_id, weekday, start_time, end_time)
select p.id, d, time '09:00', time '18:00'
from public.professionals p, generate_series(1, 6) as d
where not exists (select 1 from public.availability);
-- bloqueios / folgas pontuais
create table if not exists public.time_off (
  id uuid primary key default gen_random_uuid(),
  professional_id uuid not null references public.professionals(id) on delete cascade,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  reason text,
  check (ends_at > starts_at)
);

grant select on public.time_off to anon, authenticated;
grant all on public.time_off to service_role;
alter table public.time_off enable row level security;

drop policy if exists "time off public read" on public.time_off;
create policy "time off public read" on public.time_off
  for select to anon, authenticated using (true);

-- ---------- AGENDAMENTOS ----------
create table if not exists public.appointments (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references auth.users(id) on delete cascade,
  professional_id uuid not null references public.professionals(id) on delete restrict,
  service_id uuid not null references public.services(id) on delete restrict,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  status appointment_status not null default 'pending',
  notes text,
  created_at timestamptz not null default now(),
  check (ends_at > starts_at)
);

create index if not exists appointments_prof_time_idx
  on public.appointments (professional_id, starts_at);
create index if not exists appointments_client_idx
  on public.appointments (client_id, starts_at);

grant select, insert, update, delete on public.appointments to authenticated;
grant all on public.appointments to service_role;
alter table public.appointments enable row level security;

drop policy if exists "client reads own appointments" on public.appointments;
create policy "client reads own appointments" on public.appointments
  for select to authenticated
  using (client_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "client creates own appointments" on public.appointments;
create policy "client creates own appointments" on public.appointments
  for insert to authenticated with check (client_id = auth.uid());

drop policy if exists "client updates own appointments" on public.appointments;
create policy "client updates own appointments" on public.appointments
  for update to authenticated
  using (client_id = auth.uid() or public.has_role(auth.uid(), 'admin'))
  with check (client_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "client deletes own appointments" on public.appointments;
create policy "client deletes own appointments" on public.appointments
  for delete to authenticated
  using (client_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

-- evita dois agendamentos ativos sobrepostos para o mesmo profissional
create or replace function public.prevent_overlap()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.status in ('pending', 'confirmed') and exists (
    select 1 from public.appointments a
    where a.professional_id = new.professional_id
      and a.id <> coalesce(new.id, gen_random_uuid())
      and a.status in ('pending', 'confirmed')
      and a.starts_at < new.ends_at
      and a.ends_at > new.starts_at
  ) then
    raise exception 'Horário indisponível para este profissional';
  end if;
  return new;
end $$;

drop trigger if exists appointments_no_overlap on public.appointments;
create trigger appointments_no_overlap
  before insert or update on public.appointments
  for each row execute function public.prevent_overlap();

-- ---------- DADOS DE EXEMPLO ----------
insert into public.services (name, description, duration_minutes, price_cents)
select * from (values
  ('Corte de cabelo', 'Corte masculino ou feminino', 45, 8000),
  ('Coloração',       'Coloração completa',          120, 22000),
  ('Manicure',        'Cuidado completo das mãos',   40, 6000),
  ('Barba',           'Aparo e desenho de barba',    30, 5000)
) as t(name, description, duration_minutes, price_cents)
where not exists (select 1 from public.services);

insert into public.professionals (name, role_title)
select * from (values
  ('Ana Souza',    'Cabeleireira'),
  ('Bruno Lima',   'Barbeiro'),
  ('Carla Mendes', 'Manicure')
) as t(name, role_title)
where not exists (select 1 from public.professionals);

-- horário padrão: seg-sáb, 09:00–18:00 para todos os profissionais
insert into public.availability (professional_id, weekday, start_time, end_time)
select p.id, d, time '09:00', time '18:00'
from public.professionals p, generate_series(1, 6) as d
where not exists (select 1 from public.availability);
-- =====================================================================
-- Painel Administrativo — rode no SQL Editor do Supabase
-- =====================================================================

-- ---------- coluna extra na equipe ----------
alter table public.professionals add column if not exists is_manager boolean not null default false;
alter table public.professionals add column if not exists phone text;
alter table public.professionals add column if not exists email text;

-- ---------- ADM pode ver/gerenciar todos os profissionais ----------
drop policy if exists "professionals admin read all" on public.professionals;
create policy "professionals admin read all" on public.professionals
  for select to authenticated using (public.has_role(auth.uid(), 'admin'));

-- ---------- ADM gerencia serviços por profissional ----------
drop policy if exists "prof services admin write" on public.professional_services;
create policy "prof services admin write" on public.professional_services
  for all to authenticated using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

-- ---------- ADM gerencia horários dos profissionais ----------
drop policy if exists "availability admin write" on public.availability;
create policy "availability admin write" on public.availability
  for all to authenticated using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

drop policy if exists "time off admin write" on public.time_off;
create policy "time off admin write" on public.time_off
  for all to authenticated using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

-- ---------- HORÁRIO DE FUNCIONAMENTO DO STUDIO ----------
create table if not exists public.studio_hours (
  weekday int primary key check (weekday between 0 and 6), -- 0 = domingo
  open_time time not null default time '09:00',
  close_time time not null default time '18:00',
  closed boolean not null default false,
  updated_at timestamptz not null default now()
);

grant select on public.studio_hours to anon, authenticated;
grant insert, update, delete on public.studio_hours to authenticated;
grant all on public.studio_hours to service_role;
alter table public.studio_hours enable row level security;

drop policy if exists "studio hours public read" on public.studio_hours;
create policy "studio hours public read" on public.studio_hours
  for select to anon, authenticated using (true);

drop policy if exists "studio hours admin write" on public.studio_hours;
create policy "studio hours admin write" on public.studio_hours
  for all to authenticated using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

insert into public.studio_hours (weekday, open_time, close_time, closed)
select d, time '09:00', time '18:00', d = 0
from generate_series(0, 6) as d
on conflict (weekday) do nothing;

-- ---------- ADM pode ler perfis dos clientes ----------
drop policy if exists "admin reads profiles" on public.profiles;
create policy "admin reads profiles" on public.profiles
  for select to authenticated using (public.has_role(auth.uid(), 'admin'));

-- ---------- TORNE SEU USUÁRIO ADMIN ----------
-- troque o e-mail abaixo pelo e-mail da conta que vai administrar
insert into public.user_roles (user_id, role)
select id, 'admin' from auth.users where email = 'troque@seuemail.com'
on conflict (user_id, role) do nothing;
-- =====================================================================
-- Bucket de fotos (serviços e equipe) — rode no SQL Editor do Supabase
-- =====================================================================

insert into storage.buckets (id, name, public)
values ('fotos', 'fotos', true)
on conflict (id) do update set public = true;

-- leitura pública das imagens
drop policy if exists "fotos public read" on storage.objects;
create policy "fotos public read" on storage.objects
  for select to anon, authenticated using (bucket_id = 'fotos');

-- upload / alteração / remoção por usuários logados (admin do painel)
drop policy if exists "fotos auth insert" on storage.objects;
create policy "fotos auth insert" on storage.objects
  for insert to authenticated with check (bucket_id = 'fotos');

drop policy if exists "fotos auth update" on storage.objects;
create policy "fotos auth update" on storage.objects
  for update to authenticated using (bucket_id = 'fotos') with check (bucket_id = 'fotos');

drop policy if exists "fotos auth delete" on storage.objects;
create policy "fotos auth delete" on storage.objects
  for delete to authenticated using (bucket_id = 'fotos');
-- Categorias de serviços
create table if not exists public.service_categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  created_at timestamptz not null default now()
);

grant select on public.service_categories to anon;
grant select, insert, update, delete on public.service_categories to authenticated;
grant all on public.service_categories to service_role;

alter table public.service_categories enable row level security;

drop policy if exists "categorias visiveis para todos" on public.service_categories;
create policy "categorias visiveis para todos"
  on public.service_categories for select
  to anon, authenticated
  using (true);

drop policy if exists "admin gerencia categorias" on public.service_categories;
create policy "admin gerencia categorias"
  on public.service_categories for all
  to authenticated
  using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

-- Importa categorias já usadas nos serviços existentes
insert into public.service_categories (name)
select distinct category from public.services
where category is not null and category <> ''
on conflict (name) do nothing;

notify pgrst, 'reload schema';
-- ============================================================
-- Dados do Studio (nome, endereço e WhatsApp)
-- Rode este arquivo no SQL Editor do Supabase.
-- ============================================================

create table if not exists public.studio_settings (
  id boolean primary key default true,
  name text not null default 'Studio Emilly Viana',
  address text,
  whatsapp text,
  updated_at timestamptz not null default now(),
  constraint studio_settings_singleton check (id)
);

grant select on public.studio_settings to anon;
grant select, insert, update on public.studio_settings to authenticated;
grant all on public.studio_settings to service_role;

alter table public.studio_settings enable row level security;

drop policy if exists "studio_settings_public_read" on public.studio_settings;
create policy "studio_settings_public_read"
on public.studio_settings for select
to anon, authenticated
using (true);

drop policy if exists "studio_settings_admin_insert" on public.studio_settings;
create policy "studio_settings_admin_insert"
on public.studio_settings for insert
to authenticated
with check (public.has_role(auth.uid(), 'admin'));

drop policy if exists "studio_settings_admin_update" on public.studio_settings;
create policy "studio_settings_admin_update"
on public.studio_settings for update
to authenticated
using (public.has_role(auth.uid(), 'admin'))
with check (public.has_role(auth.uid(), 'admin'));

insert into public.studio_settings (id, name, address, whatsapp)
values (true, 'Studio Emilly Viana', null, null)
on conflict (id) do nothing;

notify pgrst, 'reload schema';
