-- =====================================================================
-- Bucket de fotos (serviços e equipe) — rode no SQL Editor do Supabase
-- =====================================================================

insert into storage.buckets (id, name, public)
values ('fotos', 'fotos', true)
on conflict (id) do update set public = true;

-- leitura pública das imagens
drop policy if exists "fotos public read" on storage.objects;
create policy "fotos public read" on storage.objects
  for select to anon, authenticated using (bucket_id = 'fotos');

-- upload / alteração / remoção por usuários logados (admin do painel)
drop policy if exists "fotos auth insert" on storage.objects;
create policy "fotos auth insert" on storage.objects
  for insert to authenticated with check (bucket_id = 'fotos');

drop policy if exists "fotos auth update" on storage.objects;
create policy "fotos auth update" on storage.objects
  for update to authenticated using (bucket_id = 'fotos') with check (bucket_id = 'fotos');

drop policy if exists "fotos auth delete" on storage.objects;
create policy "fotos auth delete" on storage.objects
  for delete to authenticated using (bucket_id = 'fotos');
