-- ================================================================
-- RODE ESTE ARQUIVO INTEIRO NO SQL EDITOR DO SUPABASE
-- Antes de rodar: troque 'troque@seuemail.com' (no final do arquivo)
-- pelo e-mail da conta que sera a administradora.
-- ================================================================

-- bloqueios / folgas pontuais
create table if not exists public.time_off (
  id uuid primary key default gen_random_uuid(),
  professional_id uuid not null references public.professionals(id) on delete cascade,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  reason text,
  check (ends_at > starts_at)
);

grant select on public.time_off to anon, authenticated;
grant all on public.time_off to service_role;
alter table public.time_off enable row level security;

drop policy if exists "time off public read" on public.time_off;
create policy "time off public read" on public.time_off
  for select to anon, authenticated using (true);

-- ---------- AGENDAMENTOS ----------
create table if not exists public.appointments (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references auth.users(id) on delete cascade,
  professional_id uuid not null references public.professionals(id) on delete restrict,
  service_id uuid not null references public.services(id) on delete restrict,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  status appointment_status not null default 'pending',
  notes text,
  created_at timestamptz not null default now(),
  check (ends_at > starts_at)
);

create index if not exists appointments_prof_time_idx
  on public.appointments (professional_id, starts_at);
create index if not exists appointments_client_idx
  on public.appointments (client_id, starts_at);

grant select, insert, update, delete on public.appointments to authenticated;
grant all on public.appointments to service_role;
alter table public.appointments enable row level security;

drop policy if exists "client reads own appointments" on public.appointments;
create policy "client reads own appointments" on public.appointments
  for select to authenticated
  using (client_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "client creates own appointments" on public.appointments;
create policy "client creates own appointments" on public.appointments
  for insert to authenticated with check (client_id = auth.uid());

drop policy if exists "client updates own appointments" on public.appointments;
create policy "client updates own appointments" on public.appointments
  for update to authenticated
  using (client_id = auth.uid() or public.has_role(auth.uid(), 'admin'))
  with check (client_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "client deletes own appointments" on public.appointments;
create policy "client deletes own appointments" on public.appointments
  for delete to authenticated
  using (client_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

-- evita dois agendamentos ativos sobrepostos para o mesmo profissional
create or replace function public.prevent_overlap()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.status in ('pending', 'confirmed') and exists (
    select 1 from public.appointments a
    where a.professional_id = new.professional_id
      and a.id <> coalesce(new.id, gen_random_uuid())
      and a.status in ('pending', 'confirmed')
      and a.starts_at < new.ends_at
      and a.ends_at > new.starts_at
  ) then
    raise exception 'Horário indisponível para este profissional';
  end if;
  return new;
end $$;

drop trigger if exists appointments_no_overlap on public.appointments;
create trigger appointments_no_overlap
  before insert or update on public.appointments
  for each row execute function public.prevent_overlap();

-- ---------- DADOS DE EXEMPLO ----------
insert into public.services (name, description, duration_minutes, price_cents)
select * from (values
  ('Corte de cabelo', 'Corte masculino ou feminino', 45, 8000),
  ('Coloração',       'Coloração completa',          120, 22000),
  ('Manicure',        'Cuidado completo das mãos',   40, 6000),
  ('Barba',           'Aparo e desenho de barba',    30, 5000)
) as t(name, description, duration_minutes, price_cents)
where not exists (select 1 from public.services);

insert into public.professionals (name, role_title)
select * from (values
  ('Ana Souza',    'Cabeleireira'),
  ('Bruno Lima',   'Barbeiro'),
  ('Carla Mendes', 'Manicure')
) as t(name, role_title)
where not exists (select 1 from public.professionals);

-- horário padrão: seg-sáb, 09:00–18:00 para todos os profissionais
insert into public.availability (professional_id, weekday, start_time, end_time)
select p.id, d, time '09:00', time '18:00'
from public.professionals p, generate_series(1, 6) as d
where not exists (select 1 from public.availability);

-- =====================================================================
-- Studio Emilly Viana — colunas extras + dados iniciais
-- Rode DEPOIS de schema.sql e schema_parte2.sql, no SQL Editor.
-- Pode rodar mais de uma vez sem duplicar.
-- =====================================================================

alter table public.services add column if not exists category text;
alter table public.services add column if not exists image_url text;

-- ---------- SERVIÇOS ----------
insert into public.services (name, description, duration_minutes, price_cents, category, image_url)
select v.name, v.description, v.duration_minutes, v.price_cents, v.category, v.image_url
from (values
  ('Design de Sobrancelhas', 'Limpeza e desenho do formato ideal com base nas medidas do seu rosto.', 30, 4500, 'Sobrancelha', 'https://images.unsplash.com/photo-1560750588-73207b1ef5b8?w=400&q=70'),
  ('Brow Lamination', 'Técnica que alinha, penteia e fixa os pelos para cima, com efeito preenchido.', 60, 13500, 'Sobrancelha', 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=400&q=70'),
  ('Laminação de Sobrancelha', 'Reestrutura os pelos das sobrancelhas deixando o fio mais alinhado e macio.', 60, 12000, 'Sobrancelha', 'https://images.unsplash.com/photo-1487412947147-5cebf100ffc2?w=400&q=70'),
  ('Extensão de Cílios Volume Russo', 'Volume intenso com fios ultrafinos aplicados fio a fio.', 120, 22000, 'Cílios', 'https://images.unsplash.com/photo-1583001931096-959e9a1a6223?w=400&q=70'),
  ('Lash Lifting', 'Curvatura natural dos cílios com efeito de alongamento por semanas.', 60, 15000, 'Cílios', 'https://images.unsplash.com/photo-1596704017254-9b121068fb31?w=400&q=70'),
  ('Escova Modeladora', 'Escova com finalização modelada para um brilho de salão.', 45, 12000, 'Cabelo', 'https://images.unsplash.com/photo-1560066984-138dadb4c035?w=400&q=70'),
  ('Hidratação Profunda', 'Tratamento reconstrutor para fios secos e quimicamente tratados.', 60, 16000, 'Cabelo', 'https://images.unsplash.com/photo-1519823551278-64ac92734fb1?w=400&q=70')
) as v(name, description, duration_minutes, price_cents, category, image_url)
where not exists (select 1 from public.services s where s.name = v.name);

-- atualiza categoria/imagem de serviços já existentes com o mesmo nome
update public.services s set category = v.category, image_url = coalesce(s.image_url, v.image_url)
from (values
  ('Design de Sobrancelhas', 'Sobrancelha', 'https://images.unsplash.com/photo-1560750588-73207b1ef5b8?w=400&q=70'),
  ('Brow Lamination', 'Sobrancelha', 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=400&q=70'),
  ('Laminação de Sobrancelha', 'Sobrancelha', 'https://images.unsplash.com/photo-1487412947147-5cebf100ffc2?w=400&q=70'),
  ('Extensão de Cílios Volume Russo', 'Cílios', 'https://images.unsplash.com/photo-1583001931096-959e9a1a6223?w=400&q=70'),
  ('Lash Lifting', 'Cílios', 'https://images.unsplash.com/photo-1596704017254-9b121068fb31?w=400&q=70'),
  ('Escova Modeladora', 'Cabelo', 'https://images.unsplash.com/photo-1560066984-138dadb4c035?w=400&q=70'),
  ('Hidratação Profunda', 'Cabelo', 'https://images.unsplash.com/photo-1519823551278-64ac92734fb1?w=400&q=70')
) as v(name, category, image_url)
where s.name = v.name and s.category is null;

-- ---------- PROFISSIONAIS ----------
insert into public.professionals (name, role_title, avatar_url, bio)
select v.name, v.role_title, v.avatar_url, v.bio
from (values
  ('Emilly Viana', 'Brow Designer', 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&q=70', 'Especialista em design e laminação de sobrancelhas.'),
  ('Cara Sweet', 'Cabeleireira', 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&q=70', 'Escova modeladora, hidratação e finalização.'),
  ('Lia Prado', 'Lash Designer', 'https://images.unsplash.com/photo-1524250502761-1ac6f2e30d43?w=200&q=70', 'Extensão de cílios e lash lifting.')
) as v(name, role_title, avatar_url, bio)
where not exists (select 1 from public.professionals p where p.name = v.name);

-- ---------- QUAIS SERVIÇOS CADA PROFISSIONAL ATENDE ----------
insert into public.professional_services (professional_id, service_id)
select p.id, s.id
from public.professionals p
join public.services s on (
  (p.name = 'Emilly Viana' and s.category = 'Sobrancelha') or
  (p.name = 'Cara Sweet' and s.category = 'Cabelo') or
  (p.name = 'Lia Prado' and s.category = 'Cílios')
)
on conflict do nothing;

-- ---------- HORÁRIOS DE TRABALHO (seg a sáb, 9h-12h e 13h-20h) ----------
insert into public.availability (professional_id, weekday, start_time, end_time)
select p.id, d.weekday, t.start_time, t.end_time
from public.professionals p
cross join (values (1),(2),(3),(4),(5),(6)) as d(weekday)
cross join (values ('09:00'::time, '12:00'::time), ('13:00'::time, '20:30'::time)) as t(start_time, end_time)
where not exists (
  select 1 from public.availability a
  where a.professional_id = p.id and a.weekday = d.weekday and a.start_time = t.start_time
);

-- =====================================================================
-- Painel Administrativo — rode no SQL Editor do Supabase
-- =====================================================================

-- ---------- coluna extra na equipe ----------
alter table public.professionals add column if not exists is_manager boolean not null default false;
alter table public.professionals add column if not exists phone text;
alter table public.professionals add column if not exists email text;

-- ---------- ADM pode ver/gerenciar todos os profissionais ----------
drop policy if exists "professionals admin read all" on public.professionals;
create policy "professionals admin read all" on public.professionals
  for select to authenticated using (public.has_role(auth.uid(), 'admin'));

-- ---------- ADM gerencia serviços por profissional ----------
drop policy if exists "prof services admin write" on public.professional_services;
create policy "prof services admin write" on public.professional_services
  for all to authenticated using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

-- ---------- ADM gerencia horários dos profissionais ----------
drop policy if exists "availability admin write" on public.availability;
create policy "availability admin write" on public.availability
  for all to authenticated using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

drop policy if exists "time off admin write" on public.time_off;
create policy "time off admin write" on public.time_off
  for all to authenticated using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

-- ---------- HORÁRIO DE FUNCIONAMENTO DO STUDIO ----------
create table if not exists public.studio_hours (
  weekday int primary key check (weekday between 0 and 6), -- 0 = domingo
  open_time time not null default time '09:00',
  close_time time not null default time '18:00',
  closed boolean not null default false,
  updated_at timestamptz not null default now()
);

grant select on public.studio_hours to anon, authenticated;
grant insert, update, delete on public.studio_hours to authenticated;
grant all on public.studio_hours to service_role;
alter table public.studio_hours enable row level security;

drop policy if exists "studio hours public read" on public.studio_hours;
create policy "studio hours public read" on public.studio_hours
  for select to anon, authenticated using (true);

drop policy if exists "studio hours admin write" on public.studio_hours;
create policy "studio hours admin write" on public.studio_hours
  for all to authenticated using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

insert into public.studio_hours (weekday, open_time, close_time, closed)
select d, time '09:00', time '18:00', d = 0
from generate_series(0, 6) as d
on conflict (weekday) do nothing;

-- ---------- ADM pode ler perfis dos clientes ----------
drop policy if exists "admin reads profiles" on public.profiles;
create policy "admin reads profiles" on public.profiles
  for select to authenticated using (public.has_role(auth.uid(), 'admin'));

-- ---------- TORNE SEU USUÁRIO ADMIN ----------
-- troque o e-mail abaixo pelo e-mail da conta que vai administrar
insert into public.user_roles (user_id, role)
select id, 'admin' from auth.users where email = 'troque@seuemail.com'
on conflict (user_id, role) do nothing;


-- recarrega o cache de schema da API
notify pgrst, 'reload schema';
