-- Categorias de serviços
create table if not exists public.service_categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  created_at timestamptz not null default now()
);

grant select on public.service_categories to anon;
grant select, insert, update, delete on public.service_categories to authenticated;
grant all on public.service_categories to service_role;

alter table public.service_categories enable row level security;

drop policy if exists "categorias visiveis para todos" on public.service_categories;
create policy "categorias visiveis para todos"
  on public.service_categories for select
  to anon, authenticated
  using (true);

drop policy if exists "admin gerencia categorias" on public.service_categories;
create policy "admin gerencia categorias"
  on public.service_categories for all
  to authenticated
  using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

-- Importa categorias já usadas nos serviços existentes
insert into public.service_categories (name)
select distinct category from public.services
where category is not null and category <> ''
on conflict (name) do nothing;

notify pgrst, 'reload schema';
