-- =====================================================================
-- 1) Cria/define a SENHA do admin e autoriza o acesso ao painel
-- 2) Limpa os serviços/profissionais de exemplo (o admin cadastra os dele)
-- Troque os dois valores abaixo antes de rodar.
-- =====================================================================

-- ---------------------------------------------------------------
-- PARTE 1 — ADMIN
-- ---------------------------------------------------------------
do $$
declare
  v_email text := 'SEU_EMAIL_AQUI';      -- e-mail do admin
  v_senha text := 'SUA_SENHA_AQUI';      -- senha desejada (min. 6 caracteres)
  v_id uuid;
begin
  select id into v_id from auth.users where email = v_email;

  if v_id is null then
    -- cria o usuário já confirmado
    insert into auth.users (
      instance_id, id, aud, role, email, encrypted_password,
      email_confirmed_at, created_at, updated_at,
      raw_app_meta_data, raw_user_meta_data
    ) values (
      '00000000-0000-0000-0000-000000000000', gen_random_uuid(), 'authenticated', 'authenticated',
      v_email, crypt(v_senha, gen_salt('bf')),
      now(), now(), now(),
      '{"provider":"email","providers":["email"]}'::jsonb, '{}'::jsonb
    ) returning id into v_id;
  else
    -- apenas troca a senha e confirma o e-mail
    update auth.users
    set encrypted_password = crypt(v_senha, gen_salt('bf')),
        email_confirmed_at = coalesce(email_confirmed_at, now()),
        updated_at = now()
    where id = v_id;
  end if;

  insert into public.user_roles (user_id, role)
  values (v_id, 'admin')
  on conflict (user_id, role) do nothing;
end $$;

-- o admin precisa ler a própria role para o painel liberar o acesso
grant select on public.user_roles to authenticated;
drop policy if exists "user reads own roles" on public.user_roles;
create policy "user reads own roles" on public.user_roles
  for select to authenticated using (user_id = auth.uid());

-- ---------------------------------------------------------------
-- PARTE 2 — LIMPAR DADOS DE EXEMPLO
-- Serviços e equipe passam a aparecer somente após o cadastro no painel.
-- ---------------------------------------------------------------
delete from public.appointments;
delete from public.professional_services;
delete from public.availability;
delete from public.time_off;
delete from public.services;
delete from public.professionals;

notify pgrst, 'reload schema';

-- Conferência
select 'services' t, count(*) from public.services
union all select 'professionals', count(*) from public.professionals
union all select 'admins', count(*) from public.user_roles where role = 'admin';
