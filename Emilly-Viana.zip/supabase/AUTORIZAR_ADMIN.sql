-- ================================================================
-- Autoriza o e-mail do admin e confirma que os horarios existem.
-- Troque SEU_EMAIL_AQUI pelo e-mail da conta administradora.
-- ================================================================

-- 1) Confirma o e-mail (libera o login sem esperar o link de confirmacao)
update auth.users
set email_confirmed_at = coalesce(email_confirmed_at, now())
where email = 'SEU_EMAIL_AQUI';

-- 2) Da a permissao de administrador
insert into public.user_roles (user_id, role)
select id, 'admin' from auth.users where email = 'SEU_EMAIL_AQUI'
on conflict (user_id, role) do nothing;

-- 3) O admin precisa poder ler a propria role (senao o painel bloqueia)
grant select on public.user_roles to authenticated;
drop policy if exists "user reads own roles" on public.user_roles;
create policy "user reads own roles" on public.user_roles
  for select to authenticated using (user_id = auth.uid());

-- 4) Cria os horarios de trabalho (seg a sab) se estiverem faltando
insert into public.availability (professional_id, weekday, start_time, end_time)
select p.id, d.weekday, t.start_time, t.end_time
from public.professionals p
cross join (values (1),(2),(3),(4),(5),(6)) as d(weekday)
cross join (values ('09:00'::time,'12:00'::time), ('13:00'::time,'20:30'::time)) as t(start_time, end_time)
where not exists (
  select 1 from public.availability a
  where a.professional_id = p.id and a.weekday = d.weekday and a.start_time = t.start_time
);

grant select on public.availability to anon, authenticated;
drop policy if exists "availability public read" on public.availability;
create policy "availability public read" on public.availability
  for select to anon, authenticated using (true);

-- 5) Conferencia final
select 'availability' t, count(*) from public.availability
union all select 'admins', count(*) from public.user_roles where role = 'admin';

notify pgrst, 'reload schema';
