-- =====================================================================
-- Studio Emilly Viana — colunas extras + dados iniciais
-- Rode DEPOIS de schema.sql e schema_parte2.sql, no SQL Editor.
-- Pode rodar mais de uma vez sem duplicar.
-- =====================================================================

alter table public.services add column if not exists category text;
alter table public.services add column if not exists image_url text;

-- ---------- SERVIÇOS ----------
insert into public.services (name, description, duration_minutes, price_cents, category, image_url)
select v.name, v.description, v.duration_minutes, v.price_cents, v.category, v.image_url
from (values
  ('Design de Sobrancelhas', 'Limpeza e desenho do formato ideal com base nas medidas do seu rosto.', 30, 4500, 'Sobrancelha', 'https://images.unsplash.com/photo-1560750588-73207b1ef5b8?w=400&q=70'),
  ('Brow Lamination', 'Técnica que alinha, penteia e fixa os pelos para cima, com efeito preenchido.', 60, 13500, 'Sobrancelha', 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=400&q=70'),
  ('Laminação de Sobrancelha', 'Reestrutura os pelos das sobrancelhas deixando o fio mais alinhado e macio.', 60, 12000, 'Sobrancelha', 'https://images.unsplash.com/photo-1487412947147-5cebf100ffc2?w=400&q=70'),
  ('Extensão de Cílios Volume Russo', 'Volume intenso com fios ultrafinos aplicados fio a fio.', 120, 22000, 'Cílios', 'https://images.unsplash.com/photo-1583001931096-959e9a1a6223?w=400&q=70'),
  ('Lash Lifting', 'Curvatura natural dos cílios com efeito de alongamento por semanas.', 60, 15000, 'Cílios', 'https://images.unsplash.com/photo-1596704017254-9b121068fb31?w=400&q=70'),
  ('Escova Modeladora', 'Escova com finalização modelada para um brilho de salão.', 45, 12000, 'Cabelo', 'https://images.unsplash.com/photo-1560066984-138dadb4c035?w=400&q=70'),
  ('Hidratação Profunda', 'Tratamento reconstrutor para fios secos e quimicamente tratados.', 60, 16000, 'Cabelo', 'https://images.unsplash.com/photo-1519823551278-64ac92734fb1?w=400&q=70')
) as v(name, description, duration_minutes, price_cents, category, image_url)
where not exists (select 1 from public.services s where s.name = v.name);

-- atualiza categoria/imagem de serviços já existentes com o mesmo nome
update public.services s set category = v.category, image_url = coalesce(s.image_url, v.image_url)
from (values
  ('Design de Sobrancelhas', 'Sobrancelha', 'https://images.unsplash.com/photo-1560750588-73207b1ef5b8?w=400&q=70'),
  ('Brow Lamination', 'Sobrancelha', 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=400&q=70'),
  ('Laminação de Sobrancelha', 'Sobrancelha', 'https://images.unsplash.com/photo-1487412947147-5cebf100ffc2?w=400&q=70'),
  ('Extensão de Cílios Volume Russo', 'Cílios', 'https://images.unsplash.com/photo-1583001931096-959e9a1a6223?w=400&q=70'),
  ('Lash Lifting', 'Cílios', 'https://images.unsplash.com/photo-1596704017254-9b121068fb31?w=400&q=70'),
  ('Escova Modeladora', 'Cabelo', 'https://images.unsplash.com/photo-1560066984-138dadb4c035?w=400&q=70'),
  ('Hidratação Profunda', 'Cabelo', 'https://images.unsplash.com/photo-1519823551278-64ac92734fb1?w=400&q=70')
) as v(name, category, image_url)
where s.name = v.name and s.category is null;

-- ---------- PROFISSIONAIS ----------
insert into public.professionals (name, role_title, avatar_url, bio)
select v.name, v.role_title, v.avatar_url, v.bio
from (values
  ('Emilly Viana', 'Brow Designer', 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&q=70', 'Especialista em design e laminação de sobrancelhas.'),
  ('Cara Sweet', 'Cabeleireira', 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&q=70', 'Escova modeladora, hidratação e finalização.'),
  ('Lia Prado', 'Lash Designer', 'https://images.unsplash.com/photo-1524250502761-1ac6f2e30d43?w=200&q=70', 'Extensão de cílios e lash lifting.')
) as v(name, role_title, avatar_url, bio)
where not exists (select 1 from public.professionals p where p.name = v.name);

-- ---------- QUAIS SERVIÇOS CADA PROFISSIONAL ATENDE ----------
insert into public.professional_services (professional_id, service_id)
select p.id, s.id
from public.professionals p
join public.services s on (
  (p.name = 'Emilly Viana' and s.category = 'Sobrancelha') or
  (p.name = 'Cara Sweet' and s.category = 'Cabelo') or
  (p.name = 'Lia Prado' and s.category = 'Cílios')
)
on conflict do nothing;

-- ---------- HORÁRIOS DE TRABALHO (seg a sáb, 9h-12h e 13h-20h) ----------
insert into public.availability (professional_id, weekday, start_time, end_time)
select p.id, d.weekday, t.start_time, t.end_time
from public.professionals p
cross join (values (1),(2),(3),(4),(5),(6)) as d(weekday)
cross join (values ('09:00'::time, '12:00'::time), ('13:00'::time, '20:30'::time)) as t(start_time, end_time)
where not exists (
  select 1 from public.availability a
  where a.professional_id = p.id and a.weekday = d.weekday and a.start_time = t.start_time
);
