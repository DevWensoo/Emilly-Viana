-- ============================================================
-- Dados do Studio (nome, endereço e WhatsApp)
-- Rode este arquivo no SQL Editor do Supabase.
-- ============================================================

create table if not exists public.studio_settings (
  id boolean primary key default true,
  name text not null default 'Studio Emilly Viana',
  address text,
  whatsapp text,
  updated_at timestamptz not null default now(),
  constraint studio_settings_singleton check (id)
);

grant select on public.studio_settings to anon;
grant select, insert, update on public.studio_settings to authenticated;
grant all on public.studio_settings to service_role;

alter table public.studio_settings enable row level security;

drop policy if exists "studio_settings_public_read" on public.studio_settings;
create policy "studio_settings_public_read"
on public.studio_settings for select
to anon, authenticated
using (true);

drop policy if exists "studio_settings_admin_insert" on public.studio_settings;
create policy "studio_settings_admin_insert"
on public.studio_settings for insert
to authenticated
with check (public.has_role(auth.uid(), 'admin'));

drop policy if exists "studio_settings_admin_update" on public.studio_settings;
create policy "studio_settings_admin_update"
on public.studio_settings for update
to authenticated
using (public.has_role(auth.uid(), 'admin'))
with check (public.has_role(auth.uid(), 'admin'));

insert into public.studio_settings (id, name, address, whatsapp)
values (true, 'Studio Emilly Viana', null, null)
on conflict (id) do nothing;

notify pgrst, 'reload schema';
