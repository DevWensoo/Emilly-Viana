-- bloqueios / folgas pontuais
create table if not exists public.time_off (
  id uuid primary key default gen_random_uuid(),
  professional_id uuid not null references public.professionals(id) on delete cascade,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  reason text,
  check (ends_at > starts_at)
);

grant select on public.time_off to anon, authenticated;
grant all on public.time_off to service_role;
alter table public.time_off enable row level security;

drop policy if exists "time off public read" on public.time_off;
create policy "time off public read" on public.time_off
  for select to anon, authenticated using (true);

-- ---------- AGENDAMENTOS ----------
create table if not exists public.appointments (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references auth.users(id) on delete cascade,
  professional_id uuid not null references public.professionals(id) on delete restrict,
  service_id uuid not null references public.services(id) on delete restrict,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  status appointment_status not null default 'pending',
  notes text,
  created_at timestamptz not null default now(),
  check (ends_at > starts_at)
);

create index if not exists appointments_prof_time_idx
  on public.appointments (professional_id, starts_at);
create index if not exists appointments_client_idx
  on public.appointments (client_id, starts_at);

grant select, insert, update, delete on public.appointments to authenticated;
grant all on public.appointments to service_role;
alter table public.appointments enable row level security;

drop policy if exists "client reads own appointments" on public.appointments;
create policy "client reads own appointments" on public.appointments
  for select to authenticated
  using (client_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "client creates own appointments" on public.appointments;
create policy "client creates own appointments" on public.appointments
  for insert to authenticated with check (client_id = auth.uid());

drop policy if exists "client updates own appointments" on public.appointments;
create policy "client updates own appointments" on public.appointments
  for update to authenticated
  using (client_id = auth.uid() or public.has_role(auth.uid(), 'admin'))
  with check (client_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "client deletes own appointments" on public.appointments;
create policy "client deletes own appointments" on public.appointments
  for delete to authenticated
  using (client_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

-- evita dois agendamentos ativos sobrepostos para o mesmo profissional
create or replace function public.prevent_overlap()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.status in ('pending', 'confirmed') and exists (
    select 1 from public.appointments a
    where a.professional_id = new.professional_id
      and a.id <> coalesce(new.id, gen_random_uuid())
      and a.status in ('pending', 'confirmed')
      and a.starts_at < new.ends_at
      and a.ends_at > new.starts_at
  ) then
    raise exception 'Horário indisponível para este profissional';
  end if;
  return new;
end $$;

drop trigger if exists appointments_no_overlap on public.appointments;
create trigger appointments_no_overlap
  before insert or update on public.appointments
  for each row execute function public.prevent_overlap();

-- ---------- DADOS DE EXEMPLO ----------
insert into public.services (name, description, duration_minutes, price_cents)
select * from (values
  ('Corte de cabelo', 'Corte masculino ou feminino', 45, 8000),
  ('Coloração',       'Coloração completa',          120, 22000),
  ('Manicure',        'Cuidado completo das mãos',   40, 6000),
  ('Barba',           'Aparo e desenho de barba',    30, 5000)
) as t(name, description, duration_minutes, price_cents)
where not exists (select 1 from public.services);

insert into public.professionals (name, role_title)
select * from (values
  ('Ana Souza',    'Cabeleireira'),
  ('Bruno Lima',   'Barbeiro'),
  ('Carla Mendes', 'Manicure')
) as t(name, role_title)
where not exists (select 1 from public.professionals);

-- horário padrão: seg-sáb, 09:00–18:00 para todos os profissionais
insert into public.availability (professional_id, weekday, start_time, end_time)
select p.id, d, time '09:00', time '18:00'
from public.professionals p, generate_series(1, 6) as d
where not exists (select 1 from public.availability);
