-- ================================================================
-- Rode no SQL Editor do Supabase para conferir/corrigir o que falta.
-- ================================================================

-- 1) Quantas linhas existem de verdade (ignora RLS)
select 'services' t, count(*) from public.services
union all select 'professionals', count(*) from public.professionals
union all select 'availability', count(*) from public.availability
union all select 'studio_hours', count(*) from public.studio_hours
union all select 'appointments', count(*) from public.appointments
union all select 'user_roles', count(*) from public.user_roles;

-- 2) Garante leitura publica dos horarios de trabalho (o app le sem login)
grant select on public.availability to anon, authenticated;
drop policy if exists "availability public read" on public.availability;
create policy "availability public read" on public.availability
  for select to anon, authenticated using (true);

grant select on public.services to anon, authenticated;
drop policy if exists "services public read" on public.services;
create policy "services public read" on public.services
  for select to anon, authenticated using (true);

grant select on public.professionals to anon, authenticated;
drop policy if exists "professionals public read" on public.professionals;
create policy "professionals public read" on public.professionals
  for select to anon, authenticated using (true);

grant select on public.professional_services to anon, authenticated;
drop policy if exists "prof services public read" on public.professional_services;
create policy "prof services public read" on public.professional_services
  for select to anon, authenticated using (true);

-- 3) Se availability estiver vazia, cria seg-sab 09:00-12:00 e 13:00-20:30
insert into public.availability (professional_id, weekday, start_time, end_time)
select p.id, d.weekday, t.start_time, t.end_time
from public.professionals p
cross join (values (1),(2),(3),(4),(5),(6)) as d(weekday)
cross join (values ('09:00'::time,'12:00'::time), ('13:00'::time,'20:30'::time)) as t(start_time, end_time)
where not exists (
  select 1 from public.availability a
  where a.professional_id = p.id and a.weekday = d.weekday and a.start_time = t.start_time
);

-- 4) Confirma quem e admin (troque o e-mail)
insert into public.user_roles (user_id, role)
select id, 'admin' from auth.users where email = 'troque@seuemail.com'
on conflict (user_id, role) do nothing;

select u.email, r.role from public.user_roles r join auth.users u on u.id = r.user_id;

notify pgrst, 'reload schema';
