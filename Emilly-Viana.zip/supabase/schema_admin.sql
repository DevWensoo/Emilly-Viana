-- =====================================================================
-- Painel Administrativo — rode no SQL Editor do Supabase
-- =====================================================================

-- ---------- coluna extra na equipe ----------
alter table public.professionals add column if not exists is_manager boolean not null default false;
alter table public.professionals add column if not exists phone text;
alter table public.professionals add column if not exists email text;

-- ---------- ADM pode ver/gerenciar todos os profissionais ----------
drop policy if exists "professionals admin read all" on public.professionals;
create policy "professionals admin read all" on public.professionals
  for select to authenticated using (public.has_role(auth.uid(), 'admin'));

-- ---------- ADM gerencia serviços por profissional ----------
drop policy if exists "prof services admin write" on public.professional_services;
create policy "prof services admin write" on public.professional_services
  for all to authenticated using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

-- ---------- ADM gerencia horários dos profissionais ----------
drop policy if exists "availability admin write" on public.availability;
create policy "availability admin write" on public.availability
  for all to authenticated using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

drop policy if exists "time off admin write" on public.time_off;
create policy "time off admin write" on public.time_off
  for all to authenticated using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

-- ---------- HORÁRIO DE FUNCIONAMENTO DO STUDIO ----------
create table if not exists public.studio_hours (
  weekday int primary key check (weekday between 0 and 6), -- 0 = domingo
  open_time time not null default time '09:00',
  close_time time not null default time '18:00',
  closed boolean not null default false,
  updated_at timestamptz not null default now()
);

grant select on public.studio_hours to anon, authenticated;
grant insert, update, delete on public.studio_hours to authenticated;
grant all on public.studio_hours to service_role;
alter table public.studio_hours enable row level security;

drop policy if exists "studio hours public read" on public.studio_hours;
create policy "studio hours public read" on public.studio_hours
  for select to anon, authenticated using (true);

drop policy if exists "studio hours admin write" on public.studio_hours;
create policy "studio hours admin write" on public.studio_hours
  for all to authenticated using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

insert into public.studio_hours (weekday, open_time, close_time, closed)
select d, time '09:00', time '18:00', d = 0
from generate_series(0, 6) as d
on conflict (weekday) do nothing;

-- ---------- ADM pode ler perfis dos clientes ----------
drop policy if exists "admin reads profiles" on public.profiles;
create policy "admin reads profiles" on public.profiles
  for select to authenticated using (public.has_role(auth.uid(), 'admin'));

-- ---------- TORNE SEU USUÁRIO ADMIN ----------
-- troque o e-mail abaixo pelo e-mail da conta que vai administrar
insert into public.user_roles (user_id, role)
select id, 'admin' from auth.users where email = 'troque@seuemail.com'
on conflict (user_id, role) do nothing;
