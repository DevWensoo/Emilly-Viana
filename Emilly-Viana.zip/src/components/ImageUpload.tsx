import { useRef, useState } from "react";
import { Camera, Loader2, Trash2 } from "lucide-react";
import { supabase } from "@/lib/supabase";

const BUCKET = "fotos";

type Props = {
  value: string;
  onChange: (url: string) => void;
  label?: string;
  folder?: string;
  rounded?: boolean;
};

export function ImageUpload({ value, onChange, label = "Foto", folder = "geral", rounded }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function handleFile(file: File) {
    setErr(null);
    setBusy(true);
    try {
      const ext = file.name.split(".").pop()?.toLowerCase() || "jpg";
      const path = `${folder}/${crypto.randomUUID()}.${ext}`;
      const { error } = await supabase.storage.from(BUCKET).upload(path, file, {
        cacheControl: "3600",
        upsert: false,
        contentType: file.type || "image/jpeg",
      });
      if (error) throw error;
      const { data } = supabase.storage.from(BUCKET).getPublicUrl(path);
      onChange(data.publicUrl);
    } catch (e) {
      setErr((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-2">
      <span className="text-xs font-semibold text-muted-foreground">{label}</span>
      <div className="flex items-center gap-3">
        {value ? (
          <img
            src={value}
            alt="Pré-visualização"
            className={`h-20 w-20 object-cover ${rounded ? "rounded-full" : "rounded-2xl"}`}
          />
        ) : (
          <div
            className={`flex h-20 w-20 items-center justify-center bg-brand-soft text-brand ${
              rounded ? "rounded-full" : "rounded-2xl"
            }`}
          >
            <Camera className="h-6 w-6" />
          </div>
        )}
        <div className="flex flex-col gap-2">
          <button
            type="button"
            disabled={busy}
            onClick={() => inputRef.current?.click()}
            className="flex items-center gap-2 rounded-full border border-brand px-4 py-2 text-sm font-semibold text-brand disabled:opacity-60"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Camera className="h-4 w-4" />}
            {busy ? "Enviando…" : value ? "Alterar foto" : "Enviar foto"}
          </button>
          {value && !busy && (
            <button
              type="button"
              onClick={() => onChange("")}
              className="flex items-center gap-2 text-sm font-semibold text-muted-foreground"
            >
              <Trash2 className="h-4 w-4" /> Remover
            </button>
          )}
        </div>
      </div>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        capture="environment"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) void handleFile(f);
          e.target.value = "";
        }}
      />
      {err && <p className="text-sm text-destructive">{err}</p>}
    </div>
  );
}
