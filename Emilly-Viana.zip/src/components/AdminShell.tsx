import { useState, type ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import {
  LayoutGrid,
  Users,
  Wrench,
  DollarSign,
  Settings,
  Bell,
  Menu,
  X,
  Home,
  CalendarDays,
} from "lucide-react";
import { useAdmin } from "@/hooks/useAdmin";

const items = [
  { to: "/", label: "Home", icon: Home },
  { to: "/admin", label: "Visão Geral", icon: LayoutGrid },
  { to: "/admin/agenda", label: "Agenda", icon: CalendarDays },
  { to: "/admin/servicos", label: "Serviços", icon: Wrench },
  { to: "/admin/equipe", label: "Equipe", icon: Users },
  { to: "/admin/financas", label: "Finanças", icon: DollarSign },
  { to: "/admin/configuracoes", label: "Studio", icon: Settings },
] as const;

function SidebarLinks({ onNavigate }: { onNavigate?: () => void }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <nav className="flex h-full flex-col gap-1 p-4">
      <div className="mb-4 flex items-center gap-3 px-2">
        <span className="flex h-10 w-10 items-center justify-center rounded-full bg-brand-soft text-sm font-bold text-brand">
          EV
        </span>
        <span className="text-sm font-extrabold text-brand">Painel ADM</span>
      </div>
      <ul className="space-y-1">
        {items.map(({ to, label, icon: Icon }) => {
          const active = pathname === to;
          return (
            <li key={to}>
              <Link
                to={to}
                onClick={onNavigate}
                className={`flex items-center gap-3 rounded-2xl px-3 py-3 text-sm font-semibold transition-colors ${
                  active ? "bg-brand-soft text-brand" : "text-muted-foreground hover:bg-muted"
                }`}
              >
                <Icon className="h-5 w-5" />
                {label}
              </Link>
            </li>
          );
        })}
      </ul>

    </nav>
  );
}

export function AdminShell({ title, children }: { title: string; children: ReactNode }) {
  const { isAdmin, loading, user } = useAdmin();
  const [open, setOpen] = useState(false);

  if (loading) {
    return (
      <main className="flex min-h-dvh items-center justify-center text-muted-foreground">
        Carregando painel…
      </main>
    );
  }

  if (!user || !isAdmin) {
    return (
      <main className="mx-auto flex min-h-dvh max-w-md flex-col items-center justify-center gap-4 px-6 text-center">
        <h1 className="text-2xl font-extrabold text-brand">Acesso restrito</h1>
        <p className="text-sm text-muted-foreground">
          Esta área é exclusiva para administradores do Studio.
        </p>
        <Link
          to="/admin/login"
          className="rounded-full bg-brand px-6 py-3 text-sm font-bold text-brand-foreground"
        >
          Entrar no Painel
        </Link>
      </main>
    );
  }

  return (
    <div className="min-h-dvh lg:flex">
      <aside className="hidden w-64 shrink-0 border-r border-border bg-card lg:block">
        <div className="sticky top-0 h-dvh">
          <SidebarLinks />
        </div>
      </aside>

      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <button
            aria-label="Fechar menu"
            onClick={() => setOpen(false)}
            className="absolute inset-0 bg-foreground/40"
          />
          <div className="absolute inset-y-0 left-0 w-72 bg-card shadow-xl">
            <button
              aria-label="Fechar menu"
              onClick={() => setOpen(false)}
              className="absolute right-3 top-3 text-muted-foreground"
            >
              <X className="h-5 w-5" />
            </button>
            <SidebarLinks onNavigate={() => setOpen(false)} />
          </div>
        </div>
      )}

      <div className="flex-1 pb-10">
        <header className="mx-auto max-w-3xl px-5 pt-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                aria-label="Abrir menu"
                onClick={() => setOpen(true)}
                className="text-foreground lg:hidden"
              >
                <Menu className="h-6 w-6" />
              </button>
              <span className="text-lg font-extrabold text-brand">Studio Emilly Viana</span>
            </div>
            <Bell className="h-5 w-5 text-foreground" />
          </div>
          <h1 className="mt-6 text-3xl font-extrabold leading-tight">{title}</h1>
        </header>
        <main className="mx-auto max-w-3xl px-5 pt-6">{children}</main>
      </div>
    </div>
  );
}
