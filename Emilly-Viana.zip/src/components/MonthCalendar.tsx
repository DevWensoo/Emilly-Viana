import { ChevronLeft, ChevronRight } from "lucide-react";

const WEEKDAYS = ["D", "S", "T", "Q", "Q", "S", "S"];

export function startOfDay(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

export function sameDay(a: Date, b: Date) {
  return a.toDateString() === b.toDateString();
}

type Props = {
  month: Date;
  onMonthChange: (d: Date) => void;
  selected: Date;
  onSelect: (d: Date) => void;
  /** Dias anteriores a esta data ficam inativos (cinza). */
  minDate?: Date;
  /** Impede navegar para meses anteriores ao mês de minDate. */
  blockPastMonths?: boolean;
};

export function MonthCalendar({
  month,
  onMonthChange,
  selected,
  onSelect,
  minDate,
  blockPastMonths = true,
}: Props) {
  const first = new Date(month.getFullYear(), month.getMonth(), 1);
  const daysInMonth = new Date(month.getFullYear(), month.getMonth() + 1, 0).getDate();
  const leading = first.getDay();
  const min = minDate ? startOfDay(minDate) : null;

  const canGoBack =
    !blockPastMonths ||
    !min ||
    new Date(month.getFullYear(), month.getMonth(), 1) >
      new Date(min.getFullYear(), min.getMonth(), 1);

  const cells: (Date | null)[] = [
    ...Array.from({ length: leading }, () => null),
    ...Array.from(
      { length: daysInMonth },
      (_, i) => new Date(month.getFullYear(), month.getMonth(), i + 1),
    ),
  ];

  return (
    <div>
      <div className="flex items-center justify-between px-1 pb-3">
        <button
          type="button"
          aria-label="Mês anterior"
          disabled={!canGoBack}
          onClick={() => onMonthChange(new Date(month.getFullYear(), month.getMonth() - 1, 1))}
          className="flex h-8 w-8 items-center justify-center rounded-full text-foreground disabled:text-muted-foreground/40"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        <p className="text-sm font-semibold capitalize text-foreground">
          {month.toLocaleDateString("pt-BR", { month: "long", year: "numeric" })}
        </p>
        <button
          type="button"
          aria-label="Próximo mês"
          onClick={() => onMonthChange(new Date(month.getFullYear(), month.getMonth() + 1, 1))}
          className="flex h-8 w-8 items-center justify-center rounded-full text-foreground"
        >
          <ChevronRight className="h-5 w-5" />
        </button>
      </div>

      <div className="grid grid-cols-7 gap-1 text-center text-[11px] text-muted-foreground">
        {WEEKDAYS.map((w, i) => (
          <span key={`${w}-${i}`}>{w}</span>
        ))}
      </div>

      <div className="mt-1 grid grid-cols-7 gap-1">
        {cells.map((d, i) => {
          if (!d) return <span key={`empty-${i}`} />;
          const disabled = !!min && startOfDay(d) < min;
          const active = sameDay(d, selected);
          return (
            <button
              key={d.toISOString()}
              type="button"
              disabled={disabled}
              onClick={() => onSelect(startOfDay(d))}
              className={`mx-auto flex h-9 w-9 items-center justify-center rounded-full text-sm font-medium transition-colors ${
                disabled
                  ? "cursor-not-allowed text-muted-foreground/40"
                  : active
                    ? "bg-primary text-primary-foreground"
                    : "text-foreground hover:bg-muted"
              }`}
            >
              {d.getDate()}
            </button>
          );
        })}
      </div>
    </div>
  );
}
