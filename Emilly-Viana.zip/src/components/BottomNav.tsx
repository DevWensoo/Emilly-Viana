import { Link, useRouterState } from "@tanstack/react-router";
import { Home, CalendarDays, User } from "lucide-react";

const items = [
  { to: "/", label: "Início", icon: Home },
  { to: "/agendamentos", label: "Agendamentos", icon: CalendarDays },
  { to: "/perfil", label: "Perfil", icon: User },
] as const;

export function BottomNav() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-card/95 backdrop-blur">
      <ul className="mx-auto flex max-w-md items-stretch justify-between px-6 py-2">
        {items.map(({ to, label, icon: Icon }) => {
          const active = pathname === to;
          return (
            <li key={to} className="flex-1">
              <Link
                to={to}
                className="flex flex-col items-center gap-1 py-1 text-[11px] font-medium"
              >
                <span
                  className={`flex h-9 w-12 items-center justify-center rounded-full transition-colors ${
                    active ? "bg-brand-soft text-brand" : "text-muted-foreground"
                  }`}
                >
                  <Icon className="h-5 w-5" />
                </span>
                <span className={active ? "text-brand" : "text-muted-foreground"}>
                  {label}
                </span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
