import { createClient } from "@supabase/supabase-js";

// Publishable (anon) key — safe to ship in the browser bundle.
export const SUPABASE_URL = "https://wheirlcnwazxxkirqlcp.supabase.co";
export const SUPABASE_PUBLISHABLE_KEY =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndoZWlybGNud2F6eHhraXJxbGNwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODgyNjYzNDEsImV4cCI6MjEwMzg0MjM0MX0.4RkJHY948yBZRa5-GsIZpQjkNLqEtVNT52qAzNIpKXQ";

export const supabase = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});
