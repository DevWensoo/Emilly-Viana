import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { LogOut } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/hooks/useAuth";
import { BottomNav } from "@/components/BottomNav";

export const Route = createFileRoute("/perfil")({
  head: () => ({
    meta: [
      { title: "Meu perfil | Studio Emilly Viana" },
      {
        name: "description",
        content: "Gerencie seus dados de contato e sua conta no Studio Emilly Viana.",
      },
      { property: "og:title", content: "Meu perfil | Studio Emilly Viana" },
      {
        property: "og:description",
        content: "Seus dados e preferências no Studio Emilly Viana.",
      },
    ],
  }),
  component: ProfilePage,
});

function ProfilePage() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  const { data: profile } = useQuery({
    queryKey: ["profile", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("full_name,phone,avatar_url")
        .eq("id", user!.id)
        .maybeSingle();
      if (error) throw error;
      return data as { full_name: string | null; phone: string | null; avatar_url: string | null } | null;
    },
  });

  async function signOut() {
    await supabase.auth.signOut();
    navigate({ to: "/login" });
  }

  return (
    <div className="min-h-screen bg-background pb-28">
      <div className="mx-auto w-full max-w-md px-5">
        <header className="pt-8">
          <h1 className="text-3xl font-extrabold tracking-tight text-foreground">Perfil</h1>
        </header>

        {!loading && !user && (
          <div className="mt-10 rounded-3xl bg-card p-6 text-center">
            <p className="text-sm text-muted-foreground">Você não está conectada.</p>
            <Link
              to="/login"
              className="mt-4 inline-block rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground"
            >
              Entrar
            </Link>
          </div>
        )}

        {user && (
          <>
            <section className="mt-6 flex items-center gap-4 rounded-3xl bg-card p-6 shadow-[0_14px_32px_-26px_oklch(0.55_0.13_355_/_0.6)]">
              <span className="flex h-16 w-16 items-center justify-center overflow-hidden rounded-full bg-brand-soft text-lg font-bold text-brand">
                {profile?.avatar_url ? (
                  <img
                    src={profile.avatar_url}
                    alt={profile.full_name ?? "Avatar"}
                    className="h-full w-full object-cover"
                  />
                ) : (
                  (profile?.full_name ?? user.email ?? "?").charAt(0).toUpperCase()
                )}
              </span>
              <div>
                <p className="text-base font-bold text-foreground">
                  {profile?.full_name ?? "Cliente"}
                </p>
                <p className="text-sm text-muted-foreground">{user.email}</p>
                {profile?.phone && (
                  <p className="text-sm text-muted-foreground">{profile.phone}</p>
                )}
              </div>
            </section>

            <button
              onClick={signOut}
              className="mt-6 flex w-full items-center justify-center gap-2 rounded-full border border-input py-4 text-sm font-semibold text-foreground"
            >
              <LogOut className="h-4 w-4" />
              Sair da conta
            </button>
          </>
        )}
      </div>
      <BottomNav />
    </div>
  );
}
