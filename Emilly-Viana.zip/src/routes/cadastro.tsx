import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Mail, Lock, Eye, EyeOff, UserRound } from "lucide-react";
import { supabase } from "@/lib/supabase";

export const Route = createFileRoute("/cadastro")({
  head: () => ({
    meta: [
      { title: "Criar conta | Studio Emilly Viana" },
      {
        name: "description",
        content:
          "Crie sua conta no Studio Emilly Viana e agende sobrancelhas, cílios e cabelo em poucos toques.",
      },
      { property: "og:title", content: "Criar conta | Studio Emilly Viana" },
      {
        property: "og:description",
        content: "Junte-se ao studio e reserve seus cuidados de beleza online.",
      },
    ],
  }),
  component: SignUpPage,
});

function SignUpPage() {
  const navigate = useNavigate();
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: { full_name: fullName },
        emailRedirectTo: window.location.origin,
      },
    });
    setLoading(false);
    if (error) {
      setError(error.message);
      return;
    }
    navigate({ to: "/" });
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-background to-brand-soft/40 px-6 pb-16">
      <div className="mx-auto w-full max-w-md">
        <header className="pt-20">
          <h1 className="text-4xl font-extrabold tracking-tight text-foreground">Criar conta</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Junte-se ao Studio Emilly Viana.
          </p>
        </header>

        <form
          onSubmit={onSubmit}
          className="mt-8 rounded-3xl bg-card p-6 shadow-[0_18px_40px_-24px_oklch(0.55_0.13_355_/_0.45)]"
        >
          <label className="text-sm font-medium text-foreground" htmlFor="name">
            Nome completo
          </label>
          <div className="mt-2 flex items-center gap-3 rounded-2xl border border-input px-4">
            <UserRound className="h-4 w-4 text-brand" />
            <input
              id="name"
              required
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="Seu nome completo"
              className="h-12 w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
            />
          </div>

          <label className="mt-5 block text-sm font-medium text-foreground" htmlFor="email">
            E-mail
          </label>
          <div className="mt-2 flex items-center gap-3 rounded-2xl border border-input px-4">
            <Mail className="h-4 w-4 text-brand" />
            <input
              id="email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="seu@email.com"
              className="h-12 w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
            />
          </div>

          <label className="mt-5 block text-sm font-medium text-foreground" htmlFor="password">
            Senha
          </label>
          <div className="mt-2 flex items-center gap-3 rounded-2xl border border-input px-4">
            <Lock className="h-4 w-4 text-brand" />
            <input
              id="password"
              type={show ? "text" : "password"}
              required
              minLength={6}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="h-12 w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
            />
            <button
              type="button"
              onClick={() => setShow((v) => !v)}
              aria-label={show ? "Ocultar senha" : "Mostrar senha"}
              className="text-muted-foreground"
            >
              {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>

          {error && <p className="mt-4 text-sm text-destructive">{error}</p>}

          <button
            type="submit"
            disabled={loading}
            className="mt-7 w-full rounded-full bg-primary py-4 text-sm font-semibold text-primary-foreground transition-opacity disabled:opacity-60"
          >
            {loading ? "Criando..." : "Criar conta"}
          </button>
        </form>

        <p className="mt-6 text-center text-sm font-semibold text-brand">
          <Link to="/login">Já tenho conta! Entrar</Link>
        </p>
      </div>
    </main>
  );
}
