import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Mail } from "lucide-react";
import { supabase } from "@/lib/supabase";

export const Route = createFileRoute("/recuperar-senha")({
  head: () => ({
    meta: [
      { title: "Recuperar senha | Studio Emilly Viana" },
      {
        name: "description",
        content:
          "Receba um link por e-mail para redefinir a senha da sua conta no Studio Emilly Viana.",
      },
      { property: "og:title", content: "Recuperar senha | Studio Emilly Viana" },
      {
        property: "og:description",
        content: "Redefina sua senha em poucos passos.",
      },
    ],
  }),
  component: ResetPage,
});

function ResetPage() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/redefinir-senha`,
    });
    setLoading(false);
    if (error) {
      setError(error.message);
      return;
    }
    setSent(true);
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-background to-brand-soft/40 px-6 pb-16">
      <div className="mx-auto w-full max-w-md">
        <header className="pt-20 text-center">
          <h1 className="text-3xl font-extrabold tracking-tight text-brand">Esqueci a senha</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Enviaremos um link de redefinição para o seu e-mail.
          </p>
        </header>

        <form
          onSubmit={onSubmit}
          className="mt-8 rounded-3xl bg-card p-6 shadow-[0_18px_40px_-24px_oklch(0.55_0.13_355_/_0.45)]"
        >
          <label className="text-sm font-medium text-foreground" htmlFor="email">
            E-mail
          </label>
          <div className="mt-2 flex items-center gap-3 rounded-2xl border border-input px-4">
            <Mail className="h-4 w-4 text-brand" />
            <input
              id="email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="seu@email.com"
              className="h-12 w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
            />
          </div>

          {error && <p className="mt-4 text-sm text-destructive">{error}</p>}
          {sent && (
            <p className="mt-4 text-sm text-brand">
              Link enviado! Verifique sua caixa de entrada.
            </p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="mt-6 w-full rounded-full bg-primary py-4 text-sm font-semibold text-primary-foreground disabled:opacity-60"
          >
            {loading ? "Enviando..." : "Enviar link"}
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-muted-foreground">
          <Link to="/login" className="font-semibold text-foreground">
            Voltar para o login
          </Link>
        </p>
      </div>
    </main>
  );
}
