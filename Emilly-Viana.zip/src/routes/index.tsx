import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Bell, Search, SlidersHorizontal, Heart, Clock } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { BottomNav } from "@/components/BottomNav";

type Service = {
  id: string;
  name: string;
  description: string | null;
  duration_minutes: number;
  price_cents: number;
  category: string | null;
  image_url: string | null;
};

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Studio Emilly Viana | Agende seus cuidados" },
      {
        name: "description",
        content:
          "Beleza, cuidado e autoestima em cada detalhe: escolha seu tratamento de sobrancelhas, cílios ou cabelo e agende online.",
      },
      { property: "og:title", content: "Studio Emilly Viana | Agende seus cuidados" },
      {
        property: "og:description",
        content: "Realce sua beleza — agende sobrancelhas, cílios e cabelo em poucos toques.",
      },
    ],
  }),
  component: HomePage,
});

function formatPrice(cents: number) {
  return `R$${(cents / 100).toFixed(0)}`;
}

function HomePage() {
  const [term, setTerm] = useState("");
  const [category, setCategory] = useState("todos");
  const [favorites, setFavorites] = useState<Record<string, boolean>>({});

  const { data: services = [], isLoading } = useQuery({
    queryKey: ["services"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("services")
        .select("id,name,description,duration_minutes,price_cents,category,image_url")
        .eq("active", true)
        .order("name");
      if (error) throw error;
      return (data ?? []) as Service[];
    },
  });

  const categories = useMemo(() => {
    const set = new Set<string>();
    services.forEach((s) => s.category && set.add(s.category));
    return ["todos", ...Array.from(set)];
  }, [services]);

  const filtered = services.filter((s) => {
    const matchTerm = s.name.toLowerCase().includes(term.trim().toLowerCase());
    const matchCat = category === "todos" || s.category === category;
    return matchTerm && matchCat;
  });

  return (
    <div className="min-h-screen bg-background pb-28">
      <div className="mx-auto w-full max-w-md px-5">
        <header className="flex items-center justify-between pt-6">
          <div className="flex items-center gap-3">
            <span className="flex h-11 w-11 items-center justify-center rounded-full bg-brand-soft text-sm font-bold text-brand">
              EV
            </span>
            <h1 className="text-xl font-extrabold tracking-tight text-brand">
              Studio Emilly Viana
            </h1>
          </div>
          <button aria-label="Notificações" className="text-brand">
            <Bell className="h-6 w-6" />
          </button>
        </header>

        <section className="pt-8">
          <h2 className="text-3xl font-extrabold tracking-tight text-foreground">
            Nossos cuidados
          </h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Realce sua beleza – Beleza, cuidado e autoestima em cada detalhe.
          </p>
        </section>

        <div className="mt-6 flex items-center gap-3 rounded-full border border-input bg-card px-5 py-3">
          <Search className="h-4 w-4 text-muted-foreground" />
          <input
            value={term}
            onChange={(e) => setTerm(e.target.value)}
            placeholder="Buscar tratamentos..."
            aria-label="Buscar tratamentos"
            className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
          />
          <SlidersHorizontal className="h-4 w-4 text-foreground" />
        </div>

        <div className="-mx-5 mt-5 flex gap-3 overflow-x-auto px-5 pb-1">
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setCategory(c)}
              className={`shrink-0 rounded-full px-6 py-3 text-sm font-medium transition-colors ${
                category === c
                  ? "bg-brand-soft text-brand"
                  : "bg-muted text-muted-foreground"
              }`}
            >
              {c}
            </button>
          ))}
        </div>

        <section className="mt-6 space-y-4">
          {isLoading && (
            <p className="py-10 text-center text-sm text-muted-foreground">
              Carregando tratamentos...
            </p>
          )}
          {!isLoading && filtered.length === 0 && (
            <p className="py-10 text-center text-sm text-muted-foreground">
              Nenhum tratamento encontrado.
            </p>
          )}
          {filtered.map((s) => (
            <article
              key={s.id}
              className="flex overflow-hidden rounded-3xl bg-card shadow-[0_14px_32px_-26px_oklch(0.55_0.13_355_/_0.6)]"
            >
              <div className="w-28 shrink-0 bg-brand-soft/60">
                {s.image_url ? (
                  <img
                    src={s.image_url}
                    alt={s.name}
                    loading="lazy"
                    className="h-full w-full object-cover"
                  />
                ) : null}
              </div>
              <div className="flex-1 p-4">
                <div className="flex items-start justify-between gap-2">
                  <h3 className="text-[15px] font-bold leading-snug text-foreground">
                    {s.name}
                  </h3>
                  <button
                    aria-label="Favoritar"
                    onClick={() =>
                      setFavorites((f) => ({ ...f, [s.id]: !f[s.id] }))
                    }
                    className="text-brand"
                  >
                    <Heart
                      className={`h-5 w-5 ${favorites[s.id] ? "fill-brand" : ""}`}
                    />
                  </button>
                </div>
                <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">
                  {s.description}
                </p>
                <div className="mt-3 flex items-end justify-between">
                  <div>
                    <p className="text-base font-bold text-brand">
                      {formatPrice(s.price_cents)}
                    </p>
                    <p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
                      <Clock className="h-3.5 w-3.5" />
                      {s.duration_minutes} Min
                    </p>
                  </div>
                  <Link
                    to="/agendamento"
                    search={{ service: s.id }}
                    className="rounded-full bg-primary px-5 py-2 text-xs font-semibold text-primary-foreground"
                  >
                    Agendar
                  </Link>
                </div>
              </div>
            </article>
          ))}
        </section>
      </div>
      <BottomNav />
    </div>
  );
}
