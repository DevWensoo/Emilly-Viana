import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Lock } from "lucide-react";
import { supabase } from "@/lib/supabase";

export const Route = createFileRoute("/redefinir-senha")({
  head: () => ({
    meta: [
      { title: "Definir nova senha | Studio Emilly Viana" },
      {
        name: "description",
        content:
          "Crie uma nova senha para acessar sua conta e seus agendamentos no Studio Emilly Viana.",
      },
      { property: "og:title", content: "Definir nova senha | Studio Emilly Viana" },
      { property: "og:description", content: "Escolha uma nova senha de acesso." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: NewPasswordPage,
});

function NewPasswordPage() {
  const navigate = useNavigate();
  const [ready, setReady] = useState(false);
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => {
      if (s) setReady(true);
    });

    async function bootstrap() {
      // 1) Sessão já criada (link com hash access_token / detectSessionInUrl).
      const { data: current } = await supabase.auth.getSession();
      if (current.session) {
        setReady(true);
        return;
      }

      const url = new URL(window.location.href);
      const hash = new URLSearchParams(url.hash.replace(/^#/, ""));

      // 2) Fluxo PKCE: ?code=...
      const code = url.searchParams.get("code");
      if (code) {
        const { error: exchangeError } = await supabase.auth.exchangeCodeForSession(code);
        if (!exchangeError) {
          setReady(true);
          return;
        }
        setError(exchangeError.message);
      }

      // 3) Fluxo token_hash: ?token_hash=...&type=recovery
      const tokenHash = url.searchParams.get("token_hash") ?? hash.get("token_hash");
      if (tokenHash) {
        const { error: otpError } = await supabase.auth.verifyOtp({
          type: "recovery",
          token_hash: tokenHash,
        });
        if (!otpError) {
          setReady(true);
          return;
        }
        setError(otpError.message);
      }

      // 4) Fluxo implícito com tokens no hash.
      const accessToken = hash.get("access_token");
      const refreshToken = hash.get("refresh_token");
      if (accessToken && refreshToken) {
        const { error: sessionError } = await supabase.auth.setSession({
          access_token: accessToken,
          refresh_token: refreshToken,
        });
        if (!sessionError) setReady(true);
        else setError(sessionError.message);
      }
    }

    void bootstrap();
    return () => sub.subscription.unsubscribe();
  }, []);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (password.length < 6) {
      setError("A senha precisa ter pelo menos 6 caracteres.");
      return;
    }
    if (password !== confirm) {
      setError("As senhas não conferem.");
      return;
    }
    setLoading(true);
    const { error: updateError } = await supabase.auth.updateUser({ password });
    setLoading(false);
    if (updateError) {
      setError(updateError.message);
      return;
    }
    setDone(true);
    await supabase.auth.signOut();
    setTimeout(() => void navigate({ to: "/login" }), 1500);
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-background to-brand-soft/40 px-6 pb-16">
      <div className="mx-auto w-full max-w-md">
        <header className="pt-20 text-center">
          <h1 className="text-3xl font-extrabold tracking-tight text-brand">Nova senha</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Escolha uma senha para acessar sua conta.
          </p>
        </header>

        {!ready && !done ? (
          <div className="mt-8 rounded-3xl bg-card p-6 text-sm text-muted-foreground">
            Abra esta página pelo link enviado no seu e-mail. Se o link expirou,{" "}
            <Link to="/recuperar-senha" className="font-semibold text-brand">
              solicite um novo
            </Link>
            .
          </div>
        ) : (
          <form
            onSubmit={onSubmit}
            className="mt-8 rounded-3xl bg-card p-6 shadow-[0_18px_40px_-24px_oklch(0.55_0.13_355_/_0.45)]"
          >
            <label className="text-sm font-medium text-foreground" htmlFor="password">
              Nova senha
            </label>
            <div className="mt-2 flex items-center gap-3 rounded-2xl border border-input px-4">
              <Lock className="h-4 w-4 text-brand" />
              <input
                id="password"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="h-12 w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
              />
            </div>

            <label className="mt-5 block text-sm font-medium text-foreground" htmlFor="confirm">
              Confirmar senha
            </label>
            <div className="mt-2 flex items-center gap-3 rounded-2xl border border-input px-4">
              <Lock className="h-4 w-4 text-brand" />
              <input
                id="confirm"
                type="password"
                required
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
                placeholder="••••••••"
                className="h-12 w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
              />
            </div>

            {error && <p className="mt-4 text-sm text-destructive">{error}</p>}
            {done && <p className="mt-4 text-sm text-brand">Senha alterada! Redirecionando…</p>}

            <button
              type="submit"
              disabled={loading}
              className="mt-6 w-full rounded-full bg-primary py-4 text-sm font-semibold text-primary-foreground disabled:opacity-60"
            >
              {loading ? "Salvando..." : "Salvar nova senha"}
            </button>
          </form>
        )}

        <p className="mt-6 text-center text-sm text-muted-foreground">
          <Link to="/login" className="font-semibold text-foreground">
            Voltar para o login
          </Link>
        </p>
      </div>
    </main>
  );
}
