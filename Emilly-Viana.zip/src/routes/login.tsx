import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Mail, Lock, Eye, EyeOff, Sparkles } from "lucide-react";
import { supabase } from "@/lib/supabase";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Login | Studio Emilly Viana" },
      {
        name: "description",
        content:
          "Entre no seu espaço de beleza e autocuidado para gerenciar os agendamentos do Studio Emilly Viana.",
      },
      { property: "og:title", content: "Login | Studio Emilly Viana" },
      {
        property: "og:description",
        content: "Acesse sua conta e agende seus cuidados de beleza.",
      },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) {
      setError("E-mail ou senha inválidos.");
      return;
    }
    navigate({ to: "/" });
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-background to-brand-soft/40 px-6 pb-16">
      <div className="mx-auto w-full max-w-md">
        <div className="pt-8">
          <span className="flex h-10 w-10 items-center justify-center rounded-full border border-brand/40 text-brand">
            <Sparkles className="h-5 w-5" />
          </span>
        </div>

        <header className="pt-16 text-center">
          <h1 className="text-4xl font-extrabold tracking-tight text-brand">Login</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Bem-vinda ao seu espaço de beleza e autocuidado.
          </p>
        </header>

        <form
          onSubmit={onSubmit}
          className="mt-8 rounded-3xl bg-card p-6 shadow-[0_18px_40px_-24px_oklch(0.55_0.13_355_/_0.45)]"
        >
          <label className="text-xs font-medium text-foreground" htmlFor="email">
            E-mail
          </label>
          <div className="mt-2 flex items-center gap-3 rounded-2xl border border-input px-4">
            <Mail className="h-4 w-4 text-brand" />
            <input
              id="email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="seu@email.com"
              className="h-12 w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
            />
          </div>

          <label className="mt-5 block text-xs font-medium text-foreground" htmlFor="password">
            Senha
          </label>
          <div className="mt-2 flex items-center gap-3 rounded-2xl border border-input px-4">
            <Lock className="h-4 w-4 text-brand" />
            <input
              id="password"
              type={show ? "text" : "password"}
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="h-12 w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
            />
            <button
              type="button"
              onClick={() => setShow((v) => !v)}
              aria-label={show ? "Ocultar senha" : "Mostrar senha"}
              className="text-muted-foreground"
            >
              {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>

          <div className="mt-3 text-right">
            <Link to="/recuperar-senha" className="text-xs font-medium text-brand">
              Esqueci a senha
            </Link>
          </div>

          {error && <p className="mt-4 text-sm text-destructive">{error}</p>}

          <button
            type="submit"
            disabled={loading}
            className="mt-5 h-13 w-full rounded-full bg-primary py-4 text-sm font-semibold text-primary-foreground transition-opacity disabled:opacity-60"
          >
            {loading ? "Entrando..." : "Entrar"}
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-muted-foreground">
          Ainda não tem conta?{" "}
          <Link to="/cadastro" className="font-semibold text-foreground">
            Criar conta
          </Link>
        </p>
      </div>
    </main>
  );
}
