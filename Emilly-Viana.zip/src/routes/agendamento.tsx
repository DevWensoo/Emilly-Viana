import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { Menu } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { MonthCalendar, startOfDay } from "@/components/MonthCalendar";
import { useAuth } from "@/hooks/useAuth";

type Service = {
  id: string;
  name: string;
  duration_minutes: number;
  price_cents: number;
};

type Professional = {
  id: string;
  name: string;
  role_title: string | null;
  avatar_url: string | null;
};

type Availability = {
  professional_id: string;
  weekday: number;
  start_time: string;
  end_time: string;
};

export const Route = createFileRoute("/agendamento")({
  validateSearch: (search: Record<string, unknown>) => ({
    service: typeof search["service"] === "string" ? (search["service"] as string) : "",
  }),
  head: () => ({
    meta: [
      { title: "Agendamento | Studio Emilly Viana" },
      {
        name: "description",
        content:
          "Escolha data, horário e profissional para o seu tratamento no Studio Emilly Viana.",
      },
      { property: "og:title", content: "Agendamento | Studio Emilly Viana" },
      {
        property: "og:description",
        content: "Selecione data, horário e profissional em poucos toques.",
      },
    ],
  }),
  component: BookingPage,
});

function toMinutes(time: string) {
  const parts = time.split(":").map(Number);
  return (parts[0] ?? 0) * 60 + (parts[1] ?? 0);
}

function label12h(minutes: number) {
  const h24 = Math.floor(minutes / 60);
  const m = minutes % 60;
  const suffix = h24 >= 12 ? "PM" : "AM";
  const h = h24 % 12 === 0 ? 12 : h24 % 12;
  return `${h}:${String(m).padStart(2, "0")} ${suffix}`;
}


function BookingPage() {
  const { service: serviceId } = Route.useSearch();
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();

  const today = useMemo(() => startOfDay(new Date()), []);
  const [month, setMonth] = useState<Date>(
    () => new Date(new Date().getFullYear(), new Date().getMonth(), 1),
  );
  const [selectedDay, setSelectedDay] = useState<Date>(() => startOfDay(new Date()));

  const [professionalId, setProfessionalId] = useState<string>("");
  const [slot, setSlot] = useState<number | null>(null);
  const [notes, setNotes] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const { data: service } = useQuery({
    queryKey: ["service", serviceId],
    enabled: !!serviceId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("services")
        .select("id,name,duration_minutes,price_cents")
        .eq("id", serviceId)
        .maybeSingle();
      if (error) throw error;
      return data as Service | null;
    },
  });

  const { data: professionals = [] } = useQuery({
    queryKey: ["professionals", serviceId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("professionals")
        .select("id,name,role_title,avatar_url")
        .eq("active", true)
        .order("name");
      if (error) throw error;
      return (data ?? []) as Professional[];
    },
  });

  useEffect(() => {
    if (!professionalId && professionals[0]) setProfessionalId(professionals[0].id);
  }, [professionals, professionalId]);

  const { data: availability = [] } = useQuery({
    queryKey: ["availability", professionalId],
    enabled: !!professionalId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("availability")
        .select("professional_id,weekday,start_time,end_time")
        .eq("professional_id", professionalId);
      if (error) throw error;
      return (data ?? []) as Availability[];
    },
  });

  // Fallback: quando o profissional nao tem horario proprio cadastrado,
  // usamos o horario de funcionamento do studio.
  const { data: studioHours = [] } = useQuery({
    queryKey: ["studio-hours"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("studio_hours")
        .select("weekday,open_time,close_time,closed");
      if (error) throw error;
      return (data ?? []) as {
        weekday: number;
        open_time: string;
        close_time: string;
        closed: boolean;
      }[];
    },
  });


  const dayStart = useMemo(() => {
    const d = new Date(selectedDay);
    d.setHours(0, 0, 0, 0);
    return d;
  }, [selectedDay]);

  const { data: booked = [] } = useQuery({
    queryKey: ["appointments", professionalId, dayStart.toISOString()],
    enabled: !!professionalId && !!user,
    queryFn: async () => {
      const end = new Date(dayStart);
      end.setDate(end.getDate() + 1);
      const { data, error } = await supabase
        .from("appointments")
        .select("starts_at,ends_at,status")
        .eq("professional_id", professionalId)
        .gte("starts_at", dayStart.toISOString())
        .lt("starts_at", end.toISOString());
      if (error) return [];
      return (data ?? []) as { starts_at: string; ends_at: string; status: string }[];
    },
  });

  const duration = service?.duration_minutes ?? 60;

  const slots = useMemo(() => {
    const weekday = selectedDay.getDay();
    let windows: { start_time: string; end_time: string }[] = availability.filter(
      (a) => a.weekday === weekday,
    );
    if (windows.length === 0) {
      windows = studioHours
        .filter((h) => h.weekday === weekday && !h.closed)
        .map((h) => ({ start_time: h.open_time, end_time: h.close_time }));
    }
    const out: number[] = [];
    windows.forEach((w) => {

      const start = toMinutes(w.start_time);
      const end = toMinutes(w.end_time);
      for (let t = start; t + duration <= end; t += duration) out.push(t);
    });
    const busy = booked
      .filter((b) => b.status === "pending" || b.status === "confirmed")
      .map((b) => ({
        start: new Date(b.starts_at).getTime(),
        end: new Date(b.ends_at).getTime(),
      }));
    return Array.from(new Set(out))
      .sort((a, b) => a - b)
      .filter((t) => {
        const s = new Date(dayStart);
        s.setMinutes(t);
        const e = new Date(s.getTime() + duration * 60000);
        if (s.getTime() < Date.now()) return false;
        return !busy.some((b) => s.getTime() < b.end && e.getTime() > b.start);
      });
  }, [availability, studioHours, booked, dayStart, duration, selectedDay]);

  async function confirm() {
    setError(null);
    if (!user) {
      navigate({ to: "/login" });
      return;
    }
    if (!service || !professionalId || slot === null) {
      setError("Escolha o horário e a profissional.");
      return;
    }
    const starts = new Date(dayStart);
    starts.setMinutes(slot);
    const ends = new Date(starts.getTime() + duration * 60000);

    setSaving(true);
    const { data, error: insertError } = await supabase
      .from("appointments")
      .insert({
        client_id: user.id,
        professional_id: professionalId,
        service_id: service.id,
        starts_at: starts.toISOString(),
        ends_at: ends.toISOString(),
        status: "pending",
        notes: notes || null,
      })
      .select("id")
      .single();
    setSaving(false);

    if (insertError) {
      setError(insertError.message);
      return;
    }
    navigate({ to: "/confirmacao", search: { id: data.id } });
  }

  return (
    <div className="min-h-screen bg-background pb-32">
      <div className="mx-auto w-full max-w-md px-5">
        <header className="pt-6">
          <button aria-label="Menu" onClick={() => navigate({ to: "/" })} className="text-foreground">
            <Menu className="h-6 w-6" />
          </button>
          <h1 className="mt-4 text-3xl font-extrabold tracking-tight text-foreground">
            Agendamento
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">Escolha Data e Horário</p>
        </header>

        {service && (
          <p className="mt-4 text-sm font-medium text-brand">
            {service.name} · {service.duration_minutes} min · R$
            {(service.price_cents / 100).toFixed(2).replace(".", ",")}
          </p>
        )}

        <section className="mt-4 rounded-3xl bg-card p-4 shadow-[0_14px_32px_-26px_oklch(0.55_0.13_355_/_0.6)]">
          <MonthCalendar
            month={month}
            onMonthChange={setMonth}
            selected={selectedDay}
            onSelect={(d) => {
              setSelectedDay(d);
              setSlot(null);
            }}
            minDate={today}
          />
        </section>

        <section className="mt-6 grid grid-cols-3 gap-3">
          {slots.length === 0 && (
            <p className="col-span-3 rounded-2xl bg-card py-6 text-center text-sm text-muted-foreground">
              Sem horários disponíveis neste dia.
            </p>
          )}
          {slots.map((t) => (
            <button
              key={t}
              onClick={() => setSlot(t)}
              className={`rounded-full border py-3 text-xs font-medium transition-colors ${
                slot === t
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-input bg-card text-foreground"
              }`}
            >
              {label12h(t)}
            </button>
          ))}
        </section>

        <section className="mt-8 rounded-3xl bg-brand-soft/40 p-5">
          <h2 className="text-center text-lg font-bold text-foreground">
            Escolha a Profissional
          </h2>
          <div className="mt-4 flex justify-center gap-5">
            {professionals.map((p) => {
              const active = p.id === professionalId;
              return (
                <button
                  key={p.id}
                  onClick={() => {
                    setProfessionalId(p.id);
                    setSlot(null);
                  }}
                  className="flex w-20 flex-col items-center gap-2"
                >
                  <span
                    className={`h-16 w-16 overflow-hidden rounded-full bg-card ring-2 ${
                      active ? "ring-brand" : "ring-transparent"
                    }`}
                  >
                    {p.avatar_url ? (
                      <img
                        src={p.avatar_url}
                        alt={p.name}
                        loading="lazy"
                        className="h-full w-full object-cover"
                      />
                    ) : null}
                  </span>
                  <span className="text-center text-[11px] font-medium leading-tight text-foreground">
                    {p.name}
                  </span>
                </button>
              );
            })}
          </div>
        </section>

        <section className="mt-6">
          <label htmlFor="notes" className="text-sm font-medium text-foreground">
            Observações (opcional)
          </label>
          <textarea
            id="notes"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={3}
            className="mt-2 w-full rounded-2xl border border-input bg-card p-4 text-sm outline-none"
            placeholder="Alguma preferência ou detalhe?"
          />
        </section>

        {error && <p className="mt-4 text-sm text-destructive">{error}</p>}
        {!authLoading && !user && (
          <p className="mt-4 text-sm text-muted-foreground">
            Entre na sua conta para confirmar o agendamento.
          </p>
        )}
      </div>

      <div className="fixed inset-x-0 bottom-0 border-t border-border bg-background/95 px-5 py-4 backdrop-blur">
        <div className="mx-auto max-w-md">
          <button
            onClick={confirm}
            disabled={saving}
            className="w-full rounded-full bg-primary py-4 text-sm font-semibold text-primary-foreground disabled:opacity-60"
          >
            {saving ? "Confirmando..." : "Confirmar Agendamento"}
          </button>
        </div>
      </div>
    </div>
  );
}
