import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Pencil, Trash2, Plus, X } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { AdminShell } from "@/components/AdminShell";
import { ImageUpload } from "@/components/ImageUpload";

export const Route = createFileRoute("/admin/servicos")({
  head: () => ({
    meta: [
      { title: "Gerenciar Serviços | Painel ADM Studio Emilly Viana" },
      {
        name: "description",
        content:
          "Cadastre, edite e remova os serviços do Studio Emilly Viana com preço, duração, categoria e imagem.",
      },
      { property: "og:title", content: "Gerenciar Serviços | Painel ADM" },
      { property: "og:description", content: "CRUD completo de serviços do Studio Emilly Viana." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <AdminShell title="Gerenciar Serviços – Painel ADM">
      <ServicesAdmin />
    </AdminShell>
  ),
});

type Service = {
  id: string;
  name: string;
  description: string | null;
  duration_minutes: number;
  price_cents: number;
  active: boolean;
  category: string | null;
  image_url: string | null;
};

const empty = {
  name: "",
  description: "",
  duration_minutes: 60,
  price: "0",
  category: "",
  image_url: "",
  active: true,
};

function ServicesAdmin() {
  const qc = useQueryClient();
  const [editing, setEditing] = useState<Service | null>(null);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ ...empty });
  const [error, setError] = useState<string | null>(null);
  const [proIds, setProIds] = useState<string[]>([]);
  const [newCategory, setNewCategory] = useState("");

  const { data: categories } = useQuery({
    queryKey: ["service-categories"],
    queryFn: async () => {
      const { data, error: e } = await supabase
        .from("service_categories")
        .select("id,name")
        .order("name");
      if (e) throw e;
      return (data ?? []) as { id: string; name: string }[];
    },
  });

  const addCategory = useMutation({
    mutationFn: async (name: string) => {
      const { error: e } = await supabase.from("service_categories").insert({ name });
      if (e) throw e;
      return name;
    },
    onSuccess: (name) => {
      void qc.invalidateQueries({ queryKey: ["service-categories"] });
      setForm((f) => ({ ...f, category: name }));
      setNewCategory("");
      setError(null);
    },
    onError: (e: Error) => setError(e.message),
  });

  const { data: services, isLoading } = useQuery({
    queryKey: ["admin-services"],
    queryFn: async () => {
      const { data, error: e } = await supabase
        .from("services")
        .select("id,name,description,duration_minutes,price_cents,active,category,image_url")
        .order("name");
      if (e) throw e;
      return (data ?? []) as Service[];
    },
  });

  const { data: pros } = useQuery({
    queryKey: ["admin-team"],
    queryFn: async () => {
      const { data, error: e } = await supabase
        .from("professionals")
        .select("id,name")
        .order("name");
      if (e) throw e;
      return (data ?? []) as { id: string; name: string }[];
    },
  });

  const save = useMutation({
    mutationFn: async () => {
      const payload = {
        name: form.name,
        description: form.description || null,
        duration_minutes: Number(form.duration_minutes) || 60,
        price_cents: Math.round(Number(String(form.price).replace(",", ".")) * 100) || 0,
        category: form.category || null,
        image_url: form.image_url || null,
        active: form.active,
      };
      let serviceId = editing?.id;
      if (editing) {
        const { error: e } = await supabase.from("services").update(payload).eq("id", editing.id);
        if (e) throw e;
      } else {
        const { data, error: e } = await supabase
          .from("services")
          .insert(payload)
          .select("id")
          .single();
        if (e) throw e;
        serviceId = (data as { id: string }).id;
      }

      if (serviceId) {
        const { error: delErr } = await supabase
          .from("professional_services")
          .delete()
          .eq("service_id", serviceId);
        if (delErr) throw delErr;
        if (proIds.length > 0) {
          const { error: insErr } = await supabase
            .from("professional_services")
            .insert(proIds.map((pid) => ({ professional_id: pid, service_id: serviceId })));
          if (insErr) throw insErr;
        }
      }
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["admin-services"] });
      void qc.invalidateQueries({ queryKey: ["services"] });
      void qc.invalidateQueries({ queryKey: ["professional_services"] });
      setOpen(false);
      setEditing(null);
      setForm({ ...empty });
      setProIds([]);
      setError(null);
    },
    onError: (e: Error) => setError(e.message),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error: e } = await supabase.from("services").delete().eq("id", id);
      if (e) throw e;
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["admin-services"] });
      void qc.invalidateQueries({ queryKey: ["services"] });
    },
    onError: (e: Error) => setError(e.message),
  });

  async function startEdit(s: Service) {
    setEditing(s);
    const { data: links } = await supabase
      .from("professional_services")
      .select("professional_id")
      .eq("service_id", s.id);
    setProIds(((links ?? []) as { professional_id: string }[]).map((l) => l.professional_id));
    setForm({
      name: s.name,
      description: s.description ?? "",
      duration_minutes: s.duration_minutes,
      price: (s.price_cents / 100).toFixed(2),
      category: s.category ?? "",
      image_url: s.image_url ?? "",
      active: s.active,
    });
    setOpen(true);
  }

  return (
    <div className="space-y-4">
      {error && <p className="text-sm text-destructive">{error}</p>}
      {isLoading && <p className="text-muted-foreground">Carregando serviços…</p>}

      <ul className="space-y-4">
        {(services ?? []).map((s) => (
          <li key={s.id} className="overflow-hidden rounded-3xl bg-card shadow-sm">
            <div className="flex">
              {s.image_url ? (
                <img src={s.image_url} alt={s.name} className="h-auto w-28 object-cover" />
              ) : (
                <div className="w-28 bg-brand-soft" />
              )}
              <div className="flex-1 p-4">
                <p className="font-bold">{s.name}</p>
                <p className="line-clamp-2 text-sm text-muted-foreground">{s.description}</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {s.duration_minutes} min · {(s.price_cents / 100).toLocaleString("pt-BR", {
                    style: "currency",
                    currency: "BRL",
                  })}
                  {!s.active && " · inativo"}
                </p>
                <div className="mt-3 flex gap-2">
                  <button
                    onClick={() => void startEdit(s)}
                    className="flex items-center gap-1 rounded-full border border-brand px-4 py-2 text-sm font-semibold text-brand"
                  >
                    <Pencil className="h-4 w-4" /> Editar
                  </button>
                  <button
                    onClick={() => {
                      if (confirm(`Excluir "${s.name}"?`)) remove.mutate(s.id);
                    }}
                    className="flex items-center gap-1 rounded-full bg-brand-soft px-4 py-2 text-sm font-semibold text-brand"
                  >
                    <Trash2 className="h-4 w-4" /> Excluir
                  </button>
                </div>
              </div>
            </div>
          </li>
        ))}
      </ul>

      <button
        onClick={() => {
          setEditing(null);
          setForm({ ...empty });
          setProIds([]);
          setOpen(true);
        }}
        className="fixed bottom-24 left-1/2 flex -translate-x-1/2 items-center gap-2 rounded-full bg-brand px-6 py-4 font-bold text-brand-foreground shadow-lg"
      >
        <Plus className="h-5 w-5" /> Adicionar Novo Serviço
      </button>

      {open && (
        <div className="fixed inset-0 z-50 flex items-end bg-black/40">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              save.mutate();
            }}
            className="max-h-[90dvh] w-full space-y-3 overflow-y-auto rounded-t-3xl bg-card p-5"
          >
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold">{editing ? "Editar serviço" : "Novo serviço"}</h2>
              <button type="button" onClick={() => setOpen(false)}>
                <X className="h-5 w-5" />
              </button>
            </div>
            <Field label="Nome">
              <input
                required
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="input"
              />
            </Field>
            <Field label="Descrição">
              <textarea
                rows={3}
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                className="input"
              />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Duração (min)">
                <input
                  type="number"
                  min={5}
                  step={5}
                  value={form.duration_minutes}
                  onChange={(e) =>
                    setForm({ ...form, duration_minutes: Number(e.target.value) })
                  }
                  className="input"
                />
              </Field>
              <Field label="Preço (R$)">
                <input
                  value={form.price}
                  onChange={(e) => setForm({ ...form, price: e.target.value })}
                  className="input"
                />
              </Field>
            </div>
            <Field label="Categoria">
              <select
                value={form.category}
                onChange={(e) => setForm({ ...form, category: e.target.value })}
                className="input"
              >
                <option value="">Sem categoria</option>
                {(categories ?? []).map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>
            </Field>
            <div className="flex gap-2">
              <input
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
                placeholder="Criar nova categoria"
                className="input flex-1"
              />
              <button
                type="button"
                disabled={!newCategory.trim() || addCategory.isPending}
                onClick={() => addCategory.mutate(newCategory.trim())}
                className="rounded-full bg-brand-soft px-4 text-sm font-semibold text-brand disabled:opacity-50"
              >
                Criar
              </button>
            </div>
            <ImageUpload
              label="Imagem do serviço"
              folder="servicos"
              value={form.image_url}
              onChange={(url) => setForm({ ...form, image_url: url })}
            />

            <div className="space-y-2">
              <span className="text-xs font-semibold text-muted-foreground">
                Profissionais que fazem este serviço
              </span>
              {(pros ?? []).length === 0 && (
                <p className="text-sm text-muted-foreground">Cadastre a equipe primeiro.</p>
              )}
              <div className="space-y-2">
                {(pros ?? []).map((p) => (
                  <label key={p.id} className="flex items-center gap-3 text-sm font-medium">
                    <input
                      type="checkbox"
                      checked={proIds.includes(p.id)}
                      onChange={(e) =>
                        setProIds((prev) =>
                          e.target.checked ? [...prev, p.id] : prev.filter((x) => x !== p.id),
                        )
                      }
                      className="h-5 w-5 accent-[var(--brand)]"
                    />
                    {p.name}
                  </label>
                ))}
              </div>
            </div>
            <label className="flex items-center gap-3 text-sm font-medium">
              <input
                type="checkbox"
                checked={form.active}
                onChange={(e) => setForm({ ...form, active: e.target.checked })}
                className="h-5 w-5 accent-[var(--brand)]"
              />
              Serviço ativo (visível no app)
            </label>
            {error && <p className="text-sm text-destructive">{error}</p>}
            <button
              type="submit"
              disabled={save.isPending}
              className="w-full rounded-full bg-brand py-4 font-bold text-brand-foreground disabled:opacity-60"
            >
              {save.isPending ? "Salvando…" : "Salvar"}
            </button>
          </form>
        </div>
      )}
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block space-y-1">
      <span className="text-xs font-semibold text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}
