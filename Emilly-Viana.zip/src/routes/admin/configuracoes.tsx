import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Clock, LogOut, MapPin, MessageCircle } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { AdminShell } from "@/components/AdminShell";

export const Route = createFileRoute("/admin/configuracoes")({
  head: () => ({
    meta: [
      { title: "Studio | Painel ADM Studio Emilly Viana" },
      {
        name: "description",
        content:
          "Defina nome, endereço, WhatsApp e os horários de funcionamento do Studio Emilly Viana.",
      },
      { property: "og:title", content: "Studio | Painel ADM" },
      {
        property: "og:description",
        content: "Dados e horários de funcionamento do Studio Emilly Viana.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <AdminShell title="Studio">
      <StudioInfo />
      <StudioHours />
    </AdminShell>
  ),
});

type Hour = { weekday: number; open_time: string; close_time: string; closed: boolean };
type Info = { name: string; address: string | null; whatsapp: string | null };

const LABELS = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];
const ORDER = [1, 2, 3, 4, 5, 6, 0];

function StudioInfo() {
  const qc = useQueryClient();
  const [form, setForm] = useState<Info>({ name: "", address: "", whatsapp: "" });
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const { data } = useQuery({
    queryKey: ["studio-settings"],
    queryFn: async () => {
      const { data: d, error: e } = await supabase
        .from("studio_settings")
        .select("name,address,whatsapp")
        .maybeSingle();
      if (e) throw e;
      return (d ?? null) as Info | null;
    },
  });

  useEffect(() => {
    if (data)
      setForm({
        name: data.name ?? "",
        address: data.address ?? "",
        whatsapp: data.whatsapp ?? "",
      });
  }, [data]);

  const save = useMutation({
    mutationFn: async () => {
      const { error: e } = await supabase.from("studio_settings").upsert(
        {
          id: true,
          name: form.name.trim() || "Studio",
          address: form.address?.trim() || null,
          whatsapp: form.whatsapp?.trim() || null,
        },
        { onConflict: "id" },
      );
      if (e) throw e;
    },
    onSuccess: () => {
      setMsg("Dados do studio salvos.");
      setErr(null);
      void qc.invalidateQueries({ queryKey: ["studio-settings"] });
    },
    onError: (e: Error) => {
      setErr(e.message);
      setMsg(null);
    },
  });

  return (
    <section className="mb-6 space-y-3 rounded-3xl bg-card p-5">
      <h2 className="text-lg font-bold">Dados do Studio</h2>
      <label className="block space-y-1">
        <span className="text-xs text-muted-foreground">Nome do studio</span>
        <input
          value={form.name}
          onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
          className="w-full rounded-2xl border border-input bg-background px-4 py-3 text-sm outline-none"
        />
      </label>
      <label className="block space-y-1">
        <span className="text-xs text-muted-foreground">Endereço</span>
        <span className="flex items-center gap-2 rounded-2xl border border-input px-4 py-3">
          <MapPin className="h-4 w-4 text-brand" />
          <input
            value={form.address ?? ""}
            onChange={(e) => setForm((f) => ({ ...f, address: e.target.value }))}
            placeholder="Rua, número, bairro, cidade"
            className="w-full bg-transparent text-sm outline-none"
          />
        </span>
      </label>
      <label className="block space-y-1">
        <span className="text-xs text-muted-foreground">WhatsApp</span>
        <span className="flex items-center gap-2 rounded-2xl border border-input px-4 py-3">
          <MessageCircle className="h-4 w-4 text-brand" />
          <input
            value={form.whatsapp ?? ""}
            onChange={(e) => setForm((f) => ({ ...f, whatsapp: e.target.value }))}
            placeholder="(00) 00000-0000"
            className="w-full bg-transparent text-sm outline-none"
          />
        </span>
      </label>
      {msg && <p className="text-sm text-brand">{msg}</p>}
      {err && <p className="text-sm text-destructive">{err}</p>}
      <button
        onClick={() => save.mutate()}
        disabled={save.isPending}
        className="w-full rounded-full bg-brand py-3 text-sm font-bold text-brand-foreground disabled:opacity-60"
      >
        {save.isPending ? "Salvando…" : "Salvar dados do studio"}
      </button>
    </section>
  );
}

function StudioHours() {
  const qc = useQueryClient();
  const [rows, setRows] = useState<Hour[]>([]);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);


  const { data, isLoading } = useQuery({
    queryKey: ["studio-hours"],
    queryFn: async () => {
      const { data: d, error: e } = await supabase
        .from("studio_hours")
        .select("weekday,open_time,close_time,closed");
      if (e) throw e;
      return (d ?? []) as Hour[];
    },
  });

  useEffect(() => {
    if (!data) return;
    setRows(
      ORDER.map(
        (w) =>
          data.find((h) => h.weekday === w) ?? {
            weekday: w,
            open_time: "09:00",
            close_time: "18:00",
            closed: w === 0,
          },
      ),
    );
  }, [data]);

  const save = useMutation({
    mutationFn: async () => {
      const payload = rows.map((r) => ({
        weekday: r.weekday,
        open_time: r.open_time.slice(0, 5),
        close_time: r.close_time.slice(0, 5),
        closed: r.closed,
      }));
      const { error: e } = await supabase
        .from("studio_hours")
        .upsert(payload, { onConflict: "weekday" });
      if (e) throw e;

      // sincroniza a disponibilidade dos profissionais com o horário do studio
      const { data: profs, error: pe } = await supabase.from("professionals").select("id");
      if (pe) throw pe;
      const { error: de } = await supabase.from("availability").delete().neq("weekday", -1);
      if (de) throw de;
      const slots = (profs ?? []).flatMap((p: { id: string }) =>
        payload
          .filter((r) => !r.closed)
          .map((r) => ({
            professional_id: p.id,
            weekday: r.weekday,
            start_time: r.open_time,
            end_time: r.close_time,
          })),
      );
      if (slots.length) {
        const { error: ie } = await supabase.from("availability").insert(slots);
        if (ie) throw ie;
      }
    },
    onSuccess: () => {
      setMessage("Horários salvos e aplicados à agenda.");
      setError(null);
      void qc.invalidateQueries({ queryKey: ["studio-hours"] });
      void qc.invalidateQueries({ queryKey: ["availability"] });
    },
    onError: (e: Error) => {
      setError(e.message);
      setMessage(null);
    },
  });

  function update(weekday: number, patch: Partial<Hour>) {
    setRows((prev) => prev.map((r) => (r.weekday === weekday ? { ...r, ...patch } : r)));
  }

  if (isLoading) return <p className="text-muted-foreground">Carregando horários…</p>;

  return (
    <div className="space-y-4 pb-6">
      <ul className="divide-y divide-border overflow-hidden rounded-3xl bg-card">
        {rows.map((r) => (
          <li key={r.weekday} className="space-y-2 p-4">
            <div className="flex items-center justify-between">
              <p className="text-lg font-semibold">{LABELS[r.weekday]}</p>
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">
                  {r.closed ? "Fechado" : "Aberto"}
                </span>
                <button
                  type="button"
                  onClick={() => update(r.weekday, { closed: !r.closed })}
                  aria-label={`Alternar ${LABELS[r.weekday]}`}
                  className={`flex h-7 w-12 items-center rounded-full p-1 transition-colors ${
                    r.closed ? "bg-muted" : "bg-brand"
                  }`}
                >
                  <span
                    className={`h-5 w-5 rounded-full bg-card transition-transform ${
                      r.closed ? "" : "translate-x-5"
                    }`}
                  />
                </button>
              </div>
            </div>
            {!r.closed && (
              <div className="grid grid-cols-2 gap-3">
                <label className="space-y-1">
                  <span className="text-xs text-muted-foreground">Abertura</span>
                  <span className="flex items-center gap-2 rounded-full border border-input px-4 py-2">
                    <Clock className="h-4 w-4 text-brand" />
                    <input
                      type="time"
                      value={r.open_time.slice(0, 5)}
                      onChange={(e) => update(r.weekday, { open_time: e.target.value })}
                      className="w-full bg-transparent outline-none"
                    />
                  </span>
                </label>
                <label className="space-y-1">
                  <span className="text-xs text-muted-foreground">Fechamento</span>
                  <span className="flex items-center gap-2 rounded-full border border-input px-4 py-2">
                    <Clock className="h-4 w-4 text-brand" />
                    <input
                      type="time"
                      value={r.close_time.slice(0, 5)}
                      onChange={(e) => update(r.weekday, { close_time: e.target.value })}
                      className="w-full bg-transparent outline-none"
                    />
                  </span>
                </label>
              </div>
            )}
          </li>
        ))}
      </ul>

      {message && <p className="text-sm text-[var(--success)]">{message}</p>}
      {error && <p className="text-sm text-destructive">{error}</p>}

      <button
        onClick={() => save.mutate()}
        disabled={save.isPending}
        className="w-full rounded-full bg-brand py-4 font-bold text-brand-foreground disabled:opacity-60"
      >
        {save.isPending ? "Salvando…" : "Salvar horários"}
      </button>

      <button
        onClick={() => void supabase.auth.signOut()}
        className="flex w-full items-center justify-center gap-2 rounded-full border border-border py-3 text-sm font-semibold"
      >
        <LogOut className="h-4 w-4" /> Sair do painel
      </button>
    </div>
  );
}
