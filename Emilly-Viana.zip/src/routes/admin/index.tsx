import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { CalendarDays, Users, Wrench, DollarSign } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { AdminShell } from "@/components/AdminShell";

export const Route = createFileRoute("/admin/")({
  head: () => ({
    meta: [
      { title: "Painel ADM | Studio Emilly Viana" },
      {
        name: "description",
        content:
          "Visão geral do Studio Emilly Viana: faturamento do mês, agendamentos, equipe e serviços cadastrados.",
      },
      { property: "og:title", content: "Painel ADM | Studio Emilly Viana" },
      { property: "og:description", content: "Visão geral da gestão do Studio Emilly Viana." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <AdminShell title="Visão Geral - Painel ADM">
      <Overview />
    </AdminShell>
  ),
});

const brl = (cents: number) =>
  (cents / 100).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

type Row = {
  id: string;
  starts_at: string;
  status: string;
  services: { name: string; price_cents: number } | null;
};

function Overview() {
  const today = new Date();
  const start = new Date(today.getFullYear(), today.getMonth(), 1).toISOString();

  const { data, isLoading } = useQuery({
    queryKey: ["admin-overview", start],
    refetchInterval: 30000,
    queryFn: async () => {
      const [appts, profs, servs] = await Promise.all([
        supabase
          .from("appointments")
          .select("id,starts_at,status,services(name,price_cents)")
          .gte("starts_at", start),
        supabase.from("professionals").select("id", { count: "exact", head: true }),
        supabase.from("services").select("id", { count: "exact", head: true }),
      ]);
      if (appts.error) throw appts.error;
      return {
        appointments: (appts.data ?? []) as unknown as Row[],
        team: profs.count ?? 0,
        services: servs.count ?? 0,
      };
    },
  });

  if (isLoading) return <p className="text-muted-foreground">Carregando dados…</p>;

  const appointments = data?.appointments ?? [];
  const revenue = appointments
    .filter((a) => a.status !== "cancelled")
    .reduce((sum, a) => sum + (a.services?.price_cents ?? 0), 0);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <Stat label="Faturamento do mês" value={brl(revenue)} icon={DollarSign} />
        <Stat label="Agendamentos do mês" value={String(appointments.length)} icon={CalendarDays} />
        <Stat label="Equipe" value={String(data?.team ?? 0)} icon={Users} />
        <Stat label="Serviços" value={String(data?.services ?? 0)} icon={Wrench} />
      </div>

      <Link
        to="/admin/agenda"
        className="flex items-center justify-center gap-2 rounded-2xl bg-brand px-4 py-3 text-sm font-bold text-brand-foreground"
      >
        <CalendarDays className="h-4 w-4" />
        Ver agenda e confirmações
      </Link>

      <div className="grid grid-cols-2 gap-3">
        <Link
          to="/admin/servicos"
          className="rounded-2xl border border-brand px-4 py-3 text-center text-sm font-bold text-brand"
        >
          Gerenciar serviços
        </Link>
        <Link
          to="/admin/equipe"
          className="rounded-2xl border border-brand px-4 py-3 text-center text-sm font-bold text-brand"
        >
          Gerenciar equipe
        </Link>
      </div>
    </div>
  );
}

function Stat({
  label,
  value,
  icon: Icon,
}: {
  label: string;
  value: string;
  icon: typeof DollarSign;
}) {
  return (
    <div className="rounded-2xl bg-card p-4 shadow-sm">
      <Icon className="h-5 w-5 text-brand" />
      <p className="mt-2 text-xs text-muted-foreground">{label}</p>
      <p className="text-xl font-extrabold">{value}</p>
    </div>
  );
}
