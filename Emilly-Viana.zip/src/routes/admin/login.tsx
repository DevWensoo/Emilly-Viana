import { useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Mail, Lock } from "lucide-react";
import { supabase } from "@/lib/supabase";

export const Route = createFileRoute("/admin/login")({
  head: () => ({
    meta: [
      { title: "Login Administrativo | Studio Emilly Viana" },
      {
        name: "description",
        content:
          "Acesso exclusivo para administradores do Studio Emilly Viana gerenciarem serviços, equipe, finanças e horários.",
      },
      { property: "og:title", content: "Login Administrativo | Studio Emilly Viana" },
      { property: "og:description", content: "Painel de gestão do Studio Emilly Viana." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AdminLogin,
});

function AdminLogin() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const { data, error: signInError } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    if (signInError || !data.user) {
      setError(signInError?.message ?? "Não foi possível entrar.");
      setBusy(false);
      return;
    }
    const { data: role } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", data.user.id)
      .eq("role", "admin")
      .maybeSingle();
    if (!role) {
      await supabase.auth.signOut();
      setError("Esta conta não tem permissão de administrador.");
      setBusy(false);
      return;
    }
    void navigate({ to: "/admin" });
  }

  return (
    <main className="mx-auto flex min-h-dvh max-w-md flex-col justify-center px-6 py-12">
      <h1 className="text-center text-4xl font-extrabold text-brand">Login Administrativo</h1>
      <p className="mt-3 text-center text-xl">Studio Emilly Viana</p>
      <p className="text-center text-muted-foreground">Painel de Gestão</p>

      <form onSubmit={onSubmit} className="mt-8 space-y-4">
        <div className="flex items-center gap-3 rounded-full border border-input bg-card px-5 py-4">
          <Mail className="h-5 w-5 text-brand" />
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="E-mail"
            className="w-full bg-transparent outline-none placeholder:text-muted-foreground"
          />
        </div>
        <div className="flex items-center gap-3 rounded-full border border-input bg-card px-5 py-4">
          <Lock className="h-5 w-5 text-brand" />
          <input
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Senha"
            className="w-full bg-transparent outline-none placeholder:text-muted-foreground"
          />
        </div>

        <div className="text-right">
          <Link to="/recuperar-senha" className="text-sm underline">
            Esqueceu sua senha?
          </Link>
        </div>

        {error && <p className="text-sm text-destructive">{error}</p>}

        <button
          type="submit"
          disabled={busy}
          className="w-full rounded-full bg-primary py-4 font-bold text-primary-foreground disabled:opacity-60"
        >
          {busy ? "Entrando…" : "Entrar no Painel"}
        </button>
      </form>

      <p className="mt-4 text-center text-sm text-muted-foreground">
        Acesso exclusivo para administradores.
      </p>
    </main>
  );
}
