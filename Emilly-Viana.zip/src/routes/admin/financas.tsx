import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/lib/supabase";
import { AdminShell } from "@/components/AdminShell";

export const Route = createFileRoute("/admin/financas")({
  head: () => ({
    meta: [
      { title: "Painel Financeiro | Painel ADM Studio Emilly Viana" },
      {
        name: "description",
        content:
          "Faturamento, número de agendamentos e ganhos diários do Studio Emilly Viana por período.",
      },
      { property: "og:title", content: "Painel Financeiro | Painel ADM" },
      { property: "og:description", content: "Indicadores financeiros do Studio Emilly Viana." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <AdminShell title="Painel Financeiro">
      <Finance />
    </AdminShell>
  ),
});

const brl = (cents: number) =>
  (cents / 100).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

const PERIODS = {
  week: "Esta Semana",
  month: "Este Mês",
  year: "Este Ano",
} as const;
type Period = keyof typeof PERIODS;

function rangeFor(period: Period) {
  const now = new Date();
  if (period === "week") {
    const d = new Date(now);
    d.setDate(now.getDate() - ((now.getDay() + 6) % 7));
    d.setHours(0, 0, 0, 0);
    return d;
  }
  if (period === "year") return new Date(now.getFullYear(), 0, 1);
  return new Date(now.getFullYear(), now.getMonth(), 1);
}

const DAYS = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];

type Row = { starts_at: string; status: string; services: { price_cents: number } | null };

function Finance() {
  const [period, setPeriod] = useState<Period>("month");
  const from = rangeFor(period).toISOString();

  const { data, isLoading } = useQuery({
    queryKey: ["admin-finance", period],
    queryFn: async () => {
      const { data: rows, error } = await supabase
        .from("appointments")
        .select("starts_at,status,services(price_cents)")
        .gte("starts_at", from);
      if (error) throw error;
      return (rows ?? []) as unknown as Row[];
    },
  });

  const rows = (data ?? []).filter((r) => r.status !== "cancelled");
  const total = rows.reduce((s, r) => s + (r.services?.price_cents ?? 0), 0);
  const perWeekday = DAYS.map((_, i) =>
    rows
      .filter((r) => new Date(r.starts_at).getDay() === i)
      .reduce((s, r) => s + (r.services?.price_cents ?? 0), 0),
  );
  const max = Math.max(...perWeekday, 1);
  const ordered = [1, 2, 3, 4, 5, 6, 0];

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        {(Object.keys(PERIODS) as Period[]).map((p) => (
          <button
            key={p}
            onClick={() => setPeriod(p)}
            className={`rounded-full border px-4 py-2 text-sm font-semibold ${
              period === p
                ? "border-brand bg-brand text-brand-foreground"
                : "border-border bg-card text-foreground"
            }`}
          >
            {PERIODS[p]}
          </button>
        ))}
      </div>

      {isLoading ? (
        <p className="text-muted-foreground">Calculando…</p>
      ) : (
        <>
          <div className="rounded-3xl bg-card p-6 shadow-sm">
            <p className="text-lg">Total Bruto:</p>
            <p className="text-4xl font-extrabold">{brl(total)}</p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-2xl border-l-4 border-brand-soft bg-card p-4 shadow-sm">
              <p className="text-sm">Ticket médio:</p>
              <p className="text-xl font-extrabold">
                {brl(rows.length ? Math.round(total / rows.length) : 0)}
              </p>
            </div>
            <div className="rounded-2xl border-l-4 border-brand-soft bg-card p-4 shadow-sm">
              <p className="text-sm">Total de Agendamentos:</p>
              <p className="text-xl font-extrabold">{rows.length}</p>
            </div>
          </div>

          <div className="rounded-3xl bg-[oklch(0.24_0.01_320)] p-5 text-white">
            <h2 className="text-xl font-bold">Ganhos Diários</h2>
            <div className="mt-6 flex items-end justify-between gap-2">
              {ordered.map((i) => {
                const value = perWeekday[i] ?? 0;
                return (
                  <div key={i} className="flex flex-1 flex-col items-center gap-2">
                    <span className="text-[10px] whitespace-nowrap">{brl(value)}</span>
                    <div
                      className="w-full rounded-md bg-brand-soft"
                      style={{ height: `${Math.max((value / max) * 140, 6)}px` }}
                    />
                    <span className="text-xs text-white/70">{DAYS[i]}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
