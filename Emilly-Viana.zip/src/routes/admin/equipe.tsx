import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { SquarePen, Trash2, X } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { AdminShell } from "@/components/AdminShell";
import { ImageUpload } from "@/components/ImageUpload";

export const Route = createFileRoute("/admin/equipe")({
  head: () => ({
    meta: [
      { title: "Cadastro de Funcionários | Painel ADM Studio Emilly Viana" },
      {
        name: "description",
        content:
          "Cadastre e edite a equipe do Studio Emilly Viana: nome, função, contato, foto e perfil administrador.",
      },
      { property: "og:title", content: "Cadastro de Funcionários | Painel ADM" },
      { property: "og:description", content: "Gestão da equipe do Studio Emilly Viana." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <AdminShell title="Cadastro de Funcionários - Painel ADM">
      <TeamAdmin />
    </AdminShell>
  ),
});

type Professional = {
  id: string;
  name: string;
  role_title: string | null;
  avatar_url: string | null;
  bio: string | null;
  phone: string | null;
  email: string | null;
  active: boolean;
  is_manager: boolean;
};

const empty = {
  name: "",
  avatar_url: "",
  phone: "",
  email: "",
  bio: "",
  active: true,
  is_manager: true,
};

function TeamAdmin() {
  const qc = useQueryClient();
  const [form, setForm] = useState({ ...empty });
  const [editing, setEditing] = useState<Professional | null>(null);
  const [error, setError] = useState<string | null>(null);

  const { data: team, isLoading } = useQuery({
    queryKey: ["admin-team"],
    queryFn: async () => {
      const { data, error: e } = await supabase
        .from("professionals")
        .select("id,name,role_title,avatar_url,bio,phone,email,active,is_manager")
        .order("name");
      if (e) throw e;
      return (data ?? []) as Professional[];
    },
  });

  const save = useMutation({
    mutationFn: async () => {
      const payload = {
        name: form.name,
        avatar_url: form.avatar_url || null,
        phone: form.phone || null,
        email: form.email || null,
        bio: form.bio || null,
        active: form.active,
        is_manager: form.is_manager,
      };
      if (editing) {
        const { error: e } = await supabase
          .from("professionals")
          .update(payload)
          .eq("id", editing.id);
        if (e) throw e;
      } else {
        const { error: e } = await supabase.from("professionals").insert(payload);
        if (e) throw e;
      }
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["admin-team"] });
      void qc.invalidateQueries({ queryKey: ["professionals"] });
      setForm({ ...empty });
      setEditing(null);
      setError(null);
    },
    onError: (e: Error) => setError(e.message),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error: e } = await supabase.from("professionals").delete().eq("id", id);
      if (e) throw e;
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["admin-team"] }),
    onError: (e: Error) => setError(e.message),
  });

  return (
    <div className="space-y-6">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          save.mutate();
        }}
        className="space-y-3 rounded-3xl bg-card p-5 shadow-sm"
      >
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold">
            {editing ? `Editando ${editing.name}` : "Novo funcionário"}
          </h2>
          {editing && (
            <button
              type="button"
              onClick={() => {
                setEditing(null);
                setForm({ ...empty });
              }}
            >
              <X className="h-5 w-5" />
            </button>
          )}
        </div>

        <input
          required
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          placeholder="Nome Completo"
          className="input"
        />

        <div className="grid grid-cols-2 gap-3">
          <input
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
            placeholder="Telefone"
            className="input"
          />
          <input
            type="email"
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            placeholder="E-mail"
            className="input"
          />
        </div>

        <ImageUpload
          label="Foto do profissional"
          folder="equipe"
          rounded
          value={form.avatar_url}
          onChange={(url) => setForm({ ...form, avatar_url: url })}
        />
        <textarea
          rows={2}
          value={form.bio}
          onChange={(e) => setForm({ ...form, bio: e.target.value })}
          placeholder="Bio / especialidades"
          className="input"
        />

        <button
          type="button"
          onClick={() => setForm({ ...form, is_manager: !form.is_manager })}
          className="flex items-center gap-3"
        >
          <span
            className={`flex h-8 w-14 items-center rounded-full p-1 transition-colors ${
              form.is_manager ? "bg-brand" : "bg-muted"
            }`}
          >
            <span
              className={`h-6 w-6 rounded-full bg-card transition-transform ${
                form.is_manager ? "translate-x-6" : ""
              }`}
            />
          </span>
          <span className="text-sm font-medium">Perfil Administrador/Dona</span>
        </button>

        <label className="flex items-center gap-3 text-sm font-medium">
          <input
            type="checkbox"
            checked={form.active}
            onChange={(e) => setForm({ ...form, active: e.target.checked })}
            className="h-5 w-5 accent-[var(--brand)]"
          />
          Ativo (aceita agendamentos)
        </label>

        {error && <p className="text-sm text-destructive">{error}</p>}

        <button
          type="submit"
          disabled={save.isPending}
          className="w-full rounded-full bg-brand py-4 font-bold text-brand-foreground disabled:opacity-60"
        >
          {save.isPending ? "Salvando…" : editing ? "Salvar alterações" : "Adicionar Funcionário"}
        </button>
      </form>

      <section>
        <h2 className="text-xl font-extrabold">Equipe Atual</h2>
        {isLoading && <p className="mt-2 text-muted-foreground">Carregando equipe…</p>}
        <ul className="mt-3 space-y-3">
          {(team ?? []).map((p) => (
            <li
              key={p.id}
              className="flex items-center gap-3 rounded-2xl bg-card p-3 shadow-sm"
            >
              {p.avatar_url ? (
                <img src={p.avatar_url} alt={p.name} className="h-12 w-12 rounded-full object-cover" />
              ) : (
                <span className="flex h-12 w-12 items-center justify-center rounded-full bg-brand-soft font-bold text-brand">
                  {p.name.charAt(0)}
                </span>
              )}
              <div className="flex-1">
                <p className="font-bold">{p.name}</p>
                <p className="text-sm text-muted-foreground">
                  {p.is_manager ? "ADM" : "Profissional"}
                  {!p.active && " · inativo"}
                </p>
              </div>
              <button
                onClick={() => {
                  setEditing(p);
                  setForm({
                    name: p.name,
                    avatar_url: p.avatar_url ?? "",
                    phone: p.phone ?? "",
                    email: p.email ?? "",
                    bio: p.bio ?? "",
                    active: p.active,
                    is_manager: p.is_manager,
                  });
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }}
                className="text-brand"
                aria-label={`Editar ${p.name}`}
              >
                <SquarePen className="h-5 w-5" />
              </button>
              <button
                onClick={() => {
                  if (confirm(`Excluir ${p.name}?`)) remove.mutate(p.id);
                }}
                className="text-muted-foreground"
                aria-label={`Excluir ${p.name}`}
              >
                <Trash2 className="h-5 w-5" />
              </button>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
