import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Check, X, CalendarDays, ChevronDown, Phone, User } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { AdminShell } from "@/components/AdminShell";
import { MonthCalendar, startOfDay, sameDay } from "@/components/MonthCalendar";
import { ConfirmDialog } from "@/components/ConfirmDialog";

export const Route = createFileRoute("/admin/agenda")({
  head: () => ({
    meta: [
      { title: "Agenda | Painel ADM Studio Emilly Viana" },
      {
        name: "description",
        content:
          "Agenda do Studio Emilly Viana: agendamentos aguardando confirmação, aprovados, recusados e a agenda do dia.",
      },
      { property: "og:title", content: "Agenda | Painel ADM Studio Emilly Viana" },
      {
        property: "og:description",
        content: "Gerencie confirmações, recusas e a agenda do dia do Studio Emilly Viana.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <AdminShell title="Agenda">
      <Agenda />
    </AdminShell>
  ),
});

type Row = {
  id: string;
  client_id: string;
  starts_at: string;
  ends_at: string;
  status: string;
  notes: string | null;
  services: { name: string; price_cents: number } | null;
  professionals: { name: string } | null;
};

type Client = { id: string; full_name: string | null; phone: string | null };

function timeLabel(iso: string) {
  return new Date(iso).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
}

function Agenda() {
  const qc = useQueryClient();
  const today = useMemo(() => startOfDay(new Date()), []);
  const [month, setMonth] = useState(
    () => new Date(new Date().getFullYear(), new Date().getMonth(), 1),
  );
  const [selectedDay, setSelectedDay] = useState<Date>(today);
  const [calendarOpen, setCalendarOpen] = useState(false);
  const [refuseId, setRefuseId] = useState<string | null>(null);

  const rangeStart = useMemo(
    () => new Date(month.getFullYear(), month.getMonth(), 1),
    [month],
  );
  const rangeEnd = useMemo(
    () => new Date(month.getFullYear(), month.getMonth() + 2, 1),
    [month],
  );

  const { data: appointments = [], isLoading } = useQuery({
    queryKey: ["admin-agenda", rangeStart.toISOString()],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("appointments")
        .select(
          "id,client_id,starts_at,ends_at,status,notes,services(name,price_cents),professionals(name)",
        )
        .gte("starts_at", rangeStart.toISOString())
        .lt("starts_at", rangeEnd.toISOString())
        .order("starts_at", { ascending: true });
      if (error) throw error;
      return (data ?? []) as unknown as Row[];
    },
    refetchInterval: 30000,
  });

  const clientIds = useMemo(
    () => Array.from(new Set(appointments.map((a) => a.client_id))),
    [appointments],
  );

  const { data: clients = {} } = useQuery({
    queryKey: ["admin-agenda-clients", clientIds],
    enabled: clientIds.length > 0,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("id,full_name,phone")
        .in("id", clientIds);
      if (error) return {};
      const map: Record<string, Client> = {};
      ((data ?? []) as Client[]).forEach((c) => {
        map[c.id] = c;
      });
      return map;
    },
  });

  const setStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await supabase.from("appointments").update({ status }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["admin-agenda"] });
      void qc.invalidateQueries({ queryKey: ["admin-overview"] });
    },
  });

  const dayRows = useMemo(
    () => appointments.filter((a) => sameDay(new Date(a.starts_at), selectedDay)),
    [appointments, selectedDay],
  );

  // Se o dia selecionado é hoje e o atendimento do dia já terminou,
  // mostramos os agendamentos do dia seguinte, deixando isso visível.
  const showingNextDay = useMemo(() => {
    if (!sameDay(selectedDay, today)) return false;
    const active = dayRows.filter((a) => a.status !== "cancelled");
    if (active.length === 0) return false;
    return active.every((a) => new Date(a.ends_at).getTime() < Date.now());
  }, [dayRows, selectedDay, today]);

  const nextDay = useMemo(() => {
    const d = new Date(selectedDay);
    d.setDate(d.getDate() + 1);
    return startOfDay(d);
  }, [selectedDay]);

  const listDay = showingNextDay ? nextDay : selectedDay;
  const listRows = showingNextDay
    ? appointments.filter((a) => sameDay(new Date(a.starts_at), nextDay))
    : dayRows;

  const pending = appointments.filter((a) => a.status === "pending");
  const approved = appointments.filter((a) => a.status === "confirmed" || a.status === "done");
  const refused = appointments.filter((a) => a.status === "cancelled");

  if (isLoading) return <p className="text-muted-foreground">Carregando agenda…</p>;

  return (
    <div className="space-y-4">
      <section className="rounded-3xl bg-card p-4 shadow-sm">
        <button
          onClick={() => setCalendarOpen((v) => !v)}
          className="flex w-full items-center justify-between rounded-2xl px-2 py-2 text-left"
        >
          <span className="flex items-center gap-3">
            <CalendarDays className="h-5 w-5 text-brand" />
            <span className="text-sm font-semibold capitalize text-foreground">
              {selectedDay.toLocaleDateString("pt-BR", {
                weekday: "long",
                day: "2-digit",
                month: "long",
                year: "numeric",
              })}
            </span>
          </span>
          <ChevronDown
            className={`h-5 w-5 text-muted-foreground transition-transform ${
              calendarOpen ? "rotate-180" : ""
            }`}
          />
        </button>
        {calendarOpen && (
          <div className="mt-3 border-t border-border pt-3">
            <MonthCalendar
              month={month}
              onMonthChange={setMonth}
              selected={selectedDay}
              onSelect={(d) => {
                setSelectedDay(d);
                setCalendarOpen(false);
              }}
              blockPastMonths={false}
            />
          </div>
        )}
      </section>

      <div className="grid grid-cols-3 gap-3">
        <Badge label="Aguardando" value={pending.length} tone="pending" />
        <Badge label="Aprovados" value={approved.length} tone="approved" />
        <Badge label="Recusados" value={refused.length} tone="refused" />
      </div>

      <section className="rounded-3xl bg-card p-5 shadow-sm">
        <div className="flex items-center justify-between gap-3">
          <h2 className="text-lg font-bold">Agendamentos do dia</h2>
          <span className="rounded-full bg-brand-soft px-3 py-1 text-[11px] font-semibold text-brand">
            {listDay.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" })}
          </span>
        </div>
        {showingNextDay && (
          <p className="mt-2 rounded-2xl bg-brand-soft/60 px-3 py-2 text-xs font-semibold text-brand">
            Atendimentos de hoje encerrados — exibindo os agendamentos do dia seguinte.
          </p>
        )}
        {listRows.length === 0 ? (
          <p className="mt-2 text-sm text-muted-foreground">Nenhum agendamento neste dia.</p>
        ) : (
          <ul className="mt-3 space-y-3">
            {listRows.map((a) => (
              <li key={a.id}>
                <ApptCard
                  row={a}
                  client={clients[a.client_id]}
                  onApprove={() => setStatus.mutate({ id: a.id, status: "confirmed" })}
                  onRefuse={() => setRefuseId(a.id)}
                />
              </li>
            ))}
          </ul>
        )}
      </section>

      <ApptList
        title="Aguardando confirmação"
        rows={pending}
        clients={clients}
        onApprove={(id) => setStatus.mutate({ id, status: "confirmed" })}
        onRefuse={(id) => setRefuseId(id)}
      />
      <ApptList title="Aprovados" rows={approved} clients={clients} />
      <ApptList title="Recusados" rows={refused} clients={clients} />

      <ConfirmDialog
        open={!!refuseId}
        title="Recusar agendamento?"
        description="O cliente será avisado e o horário voltará a ficar disponível na agenda."
        confirmLabel="Sim, recusar"
        onConfirm={() => {
          if (refuseId) setStatus.mutate({ id: refuseId, status: "cancelled" });
        }}
        onClose={() => setRefuseId(null)}
      />
    </div>
  );
}

const statusLabel: Record<string, string> = {
  pending: "Aguardando confirmação",
  confirmed: "Aprovado",
  cancelled: "Recusado / cancelado",
  done: "Concluído",
};

function ApptCard({
  row,
  client,
  onApprove,
  onRefuse,
}: {
  row: Row;
  client?: Client | undefined;
  onApprove?: () => void;
  onRefuse?: () => void;
}) {
  const showActions = row.status === "pending" && !!onApprove && !!onRefuse;
  return (
    <div className="rounded-2xl border border-border p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-sm font-bold text-foreground">{row.services?.name ?? "Serviço"}</p>
          <p className="mt-1 flex items-center gap-2 text-xs text-muted-foreground">
            <User className="h-3.5 w-3.5" />
            {client?.full_name ?? "Cliente"}
          </p>
          {client?.phone && (
            <a
              href={`tel:${client.phone.replace(/\D/g, "")}`}
              className="mt-1 flex items-center gap-2 text-xs font-medium text-brand"
            >
              <Phone className="h-3.5 w-3.5" />
              {client.phone}
            </a>
          )}
          <p className="mt-1 text-xs text-muted-foreground">
            {row.professionals?.name ?? "—"} ·{" "}
            {new Date(row.starts_at).toLocaleDateString("pt-BR", {
              day: "2-digit",
              month: "2-digit",
            })}{" "}
            · {timeLabel(row.starts_at)}
          </p>
          {row.notes && <p className="mt-1 text-xs text-muted-foreground">Obs.: {row.notes}</p>}
        </div>
        <div className="flex flex-col items-end gap-2">
          <span className="rounded-full bg-muted px-3 py-1 text-[10px] font-semibold text-muted-foreground">
            {statusLabel[row.status] ?? row.status}
          </span>
          {showActions && (
            <div className="flex gap-2">
              <button
                onClick={onApprove}
                aria-label="Aprovar"
                className="flex h-9 w-9 items-center justify-center rounded-full bg-brand text-brand-foreground"
              >
                <Check className="h-4 w-4" />
              </button>
              <button
                onClick={onRefuse}
                aria-label="Recusar"
                className="flex h-9 w-9 items-center justify-center rounded-full border border-destructive text-destructive"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function ApptList({
  title,
  rows,
  clients,
  onApprove,
  onRefuse,
}: {
  title: string;
  rows: Row[];
  clients: Record<string, Client>;
  onApprove?: (id: string) => void;
  onRefuse?: (id: string) => void;
}) {
  return (
    <section className="rounded-3xl bg-card p-5 shadow-sm">
      <h2 className="text-lg font-bold">{title}</h2>
      {rows.length === 0 ? (
        <p className="mt-2 text-sm text-muted-foreground">Nenhum agendamento.</p>
      ) : (
        <ul className="mt-3 space-y-3">
          {rows.map((a) => (
            <li key={a.id}>
              <ApptCard
                row={a}
                client={clients[a.client_id]}
                {...(onApprove ? { onApprove: () => onApprove(a.id) } : {})}
                {...(onRefuse ? { onRefuse: () => onRefuse(a.id) } : {})}
              />
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

function Badge({
  label,
  value,
  tone,
}: {
  label: string;
  value: number;
  tone: "pending" | "approved" | "refused";
}) {
  const cls =
    tone === "approved"
      ? "bg-brand text-brand-foreground"
      : tone === "refused"
        ? "border border-destructive text-destructive"
        : "bg-brand-soft text-brand";
  return (
    <div className={`rounded-2xl p-4 text-center ${cls}`}>
      <p className="text-2xl font-extrabold">{value}</p>
      <p className="text-xs font-medium">{label}</p>
    </div>
  );
}
