import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Clock } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/hooks/useAuth";
import { BottomNav } from "@/components/BottomNav";
import { ConfirmDialog } from "@/components/ConfirmDialog";

export const Route = createFileRoute("/agendamentos")({
  head: () => ({
    meta: [
      { title: "Meus agendamentos | Studio Emilly Viana" },
      {
        name: "description",
        content:
          "Acompanhe, revise e cancele seus agendamentos de beleza no Studio Emilly Viana.",
      },
      { property: "og:title", content: "Meus agendamentos | Studio Emilly Viana" },
      {
        property: "og:description",
        content: "Todos os seus horários reservados em um só lugar.",
      },
    ],
  }),
  component: AppointmentsPage,
});

type Row = {
  id: string;
  starts_at: string;
  ends_at: string;
  status: string;
  services: { name: string; price_cents: number } | null;
  professionals: { name: string; avatar_url: string | null } | null;
};

const statusLabel: Record<string, string> = {
  pending: "Pendente",
  confirmed: "Confirmado",
  cancelled: "Cancelado",
  done: "Concluído",
};

function AppointmentsPage() {
  const { user, loading } = useAuth();
  const queryClient = useQueryClient();
  const [cancelId, setCancelId] = useState<string | null>(null);

  const { data: rows = [], isLoading } = useQuery({
    queryKey: ["my-appointments", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("appointments")
        .select(
          "id,starts_at,ends_at,status,services(name,price_cents),professionals(name,avatar_url)",
        )
        .order("starts_at", { ascending: true });
      if (error) throw error;
      return (data ?? []) as unknown as Row[];
    },
  });

  async function cancel(id: string) {
    await supabase.from("appointments").update({ status: "cancelled" }).eq("id", id);
    queryClient.invalidateQueries({ queryKey: ["my-appointments"] });
  }

  return (
    <div className="min-h-screen bg-background pb-28">
      <div className="mx-auto w-full max-w-md px-5">
        <header className="pt-8">
          <h1 className="text-3xl font-extrabold tracking-tight text-foreground">
            Meus agendamentos
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Seus horários reservados no studio.
          </p>
        </header>

        {!loading && !user && (
          <div className="mt-10 rounded-3xl bg-card p-6 text-center">
            <p className="text-sm text-muted-foreground">
              Entre na sua conta para ver seus agendamentos.
            </p>
            <Link
              to="/login"
              className="mt-4 inline-block rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground"
            >
              Entrar
            </Link>
          </div>
        )}

        {user && isLoading && (
          <p className="mt-10 text-center text-sm text-muted-foreground">Carregando...</p>
        )}

        {user && !isLoading && rows.length === 0 && (
          <div className="mt-10 rounded-3xl bg-card p-6 text-center">
            <p className="text-sm text-muted-foreground">
              Você ainda não tem agendamentos.
            </p>
            <Link
              to="/"
              className="mt-4 inline-block rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground"
            >
              Agendar agora
            </Link>
          </div>
        )}

        <section className="mt-6 space-y-4">
          {rows.map((r) => {
            const starts = new Date(r.starts_at);
            return (
              <article
                key={r.id}
                className="rounded-3xl bg-card p-5 shadow-[0_14px_32px_-26px_oklch(0.55_0.13_355_/_0.6)]"
              >
                <div className="flex items-center justify-between">
                  <h2 className="text-sm font-bold text-foreground">
                    {r.services?.name ?? "Serviço"}
                  </h2>
                  <span className="rounded-full bg-brand-soft px-3 py-1 text-[11px] font-semibold text-brand">
                    {statusLabel[r.status] ?? r.status}
                  </span>
                </div>
                <p className="mt-1 text-xs text-muted-foreground">
                  com {r.professionals?.name ?? "—"}
                </p>
                <div className="mt-4 flex items-center justify-between border-t border-border pt-4 text-sm">
                  <span className="capitalize text-foreground">
                    {starts.toLocaleDateString("pt-BR", {
                      day: "2-digit",
                      month: "long",
                    })}
                  </span>
                  <span className="flex items-center gap-2 font-medium text-brand">
                    <Clock className="h-4 w-4" />
                    {starts.toLocaleTimeString("pt-BR", {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </span>
                </div>
                {(r.status === "pending" || r.status === "confirmed") && (
                  <button
                    onClick={() => setCancelId(r.id)}
                    className="mt-4 w-full rounded-full border border-input py-3 text-xs font-semibold text-foreground"
                  >
                    Cancelar agendamento
                  </button>
                )}
              </article>
            );
          })}
        </section>
      </div>
      <ConfirmDialog
        open={!!cancelId}
        title="Cancelar agendamento?"
        description="Essa ação libera o horário e não pode ser desfeita."
        onConfirm={() => {
          if (cancelId) void cancel(cancelId);
        }}
        onClose={() => setCancelId(null)}
      />
      <BottomNav />
    </div>
  );
}
