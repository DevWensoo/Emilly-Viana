import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Check, Clock, MapPin, MessageCircle } from "lucide-react";
import { supabase } from "@/lib/supabase";

export const Route = createFileRoute("/confirmacao")({
  validateSearch: (search: Record<string, unknown>) => ({
    id: typeof search["id"] === "string" ? (search["id"] as string) : "",
  }),
  head: () => ({
    meta: [
      { title: "Agendamento confirmado | Studio Emilly Viana" },
      {
        name: "description",
        content:
          "Seu agendamento no Studio Emilly Viana está confirmado. Veja o resumo com profissional, data, horário e valor.",
      },
      { property: "og:title", content: "Agendamento confirmado | Studio Emilly Viana" },
      {
        property: "og:description",
        content: "Resumo do seu agendamento no Studio Emilly Viana.",
      },
    ],
  }),
  component: ConfirmationPage,
});

type AppointmentDetail = {
  id: string;
  starts_at: string;
  ends_at: string;
  services: { name: string; price_cents: number; duration_minutes: number } | null;
  professionals: { name: string; role_title: string | null; avatar_url: string | null } | null;
};

function ConfirmationPage() {
  const { id } = Route.useSearch();

  const { data: studio } = useQuery({
    queryKey: ["studio-settings"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("studio_settings")
        .select("name,address,whatsapp")
        .maybeSingle();
      if (error) throw error;
      return (data ?? null) as { name: string; address: string | null; whatsapp: string | null } | null;
    },
  });

  const { data: appointment } = useQuery({
    queryKey: ["appointment", id],
    enabled: !!id,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("appointments")
        .select(
          "id,starts_at,ends_at,services(name,price_cents,duration_minutes),professionals(name,role_title,avatar_url)",
        )
        .eq("id", id)
        .maybeSingle();
      if (error) throw error;
      return data as unknown as AppointmentDetail | null;
    },
  });

  const starts = appointment ? new Date(appointment.starts_at) : null;
  const durationMin = appointment
    ? Math.round(
        (new Date(appointment.ends_at).getTime() - new Date(appointment.starts_at).getTime()) /
          60000,
      )
    : null;

  return (
    <main className="min-h-screen bg-gradient-to-b from-brand-soft/50 to-background px-5 pb-14">
      <div className="mx-auto w-full max-w-md">
        <div className="flex justify-center pt-14">
          <span className="flex h-24 w-24 items-center justify-center rounded-full border-2 border-success text-success">
            <Check className="h-10 w-10" />
          </span>
        </div>

        <h1 className="mt-8 text-center text-3xl font-extrabold leading-tight tracking-tight text-foreground">
          Agendamento
          <br />
          Confirmado!
        </h1>
        <p className="mt-3 text-center text-sm text-muted-foreground">
          Te esperamos no endereço: Avenida Nordestina, 1200 – São Paulo
        </p>

        <section className="mt-8 rounded-3xl bg-card p-6 shadow-[0_18px_40px_-26px_oklch(0.55_0.13_355_/_0.5)]">
          <h2 className="text-sm font-bold text-brand">Resumo do Agendamento</h2>

          <div className="mt-4 flex items-center gap-3">
            <span className="h-12 w-12 overflow-hidden rounded-full bg-brand-soft">
              {appointment?.professionals?.avatar_url ? (
                <img
                  src={appointment.professionals.avatar_url}
                  alt={appointment.professionals.name}
                  className="h-full w-full object-cover"
                />
              ) : null}
            </span>
            <div>
              <p className="text-sm font-bold text-foreground">
                {appointment?.professionals?.name ?? "—"}
              </p>
              <p className="text-xs text-muted-foreground">
                {appointment?.professionals?.role_title ?? ""}
                {appointment?.services?.name ? ` – ${appointment.services.name}` : ""}
              </p>
            </div>
          </div>

          <div className="mt-5 flex items-center justify-between border-t border-border pt-5 text-sm">
            <span className="text-foreground">
              {starts
                ? starts.toLocaleDateString("pt-BR", { day: "2-digit", month: "long" })
                : "—"}
            </span>
            <span className="flex items-center gap-2 font-medium text-brand">
              <Clock className="h-4 w-4" />
              {starts
                ? starts.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })
                : "—"}
            </span>
          </div>

          <div className="mt-5 flex items-end justify-between border-t border-border pt-5">
            <div>
              <p className="text-[11px] uppercase tracking-wide text-muted-foreground">
                Duração
              </p>
              <p className="text-sm font-bold text-foreground">
                {durationMin ? `${durationMin} min` : "—"}
              </p>
            </div>
            <div className="text-right">
              <p className="text-[11px] uppercase tracking-wide text-muted-foreground">Total</p>
              <p className="text-2xl font-extrabold text-brand">
                {appointment?.services
                  ? `R$ ${(appointment.services.price_cents / 100)
                      .toFixed(2)
                      .replace(".", ",")}`
                  : "—"}
              </p>
            </div>
          </div>
        </section>

        {(studio?.address || studio?.whatsapp) && (
          <section className="mt-5 space-y-3 rounded-3xl bg-card p-5">
            <h2 className="text-sm font-bold text-brand">{studio?.name ?? "Studio"}</h2>
            {studio?.address && (
              <p className="flex items-start gap-2 text-sm text-foreground">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-brand" />
                {studio.address}
              </p>
            )}
            {studio?.whatsapp && (
              <p className="flex items-center gap-2 text-sm text-foreground">
                <MessageCircle className="h-4 w-4 shrink-0 text-brand" />
                {studio.whatsapp}
              </p>
            )}
          </section>
        )}

        <Link
          to="/agendamentos"
          className="mt-7 block rounded-full bg-primary py-4 text-center text-sm font-semibold text-primary-foreground"
        >
          Ver meus agendamentos
        </Link>
        <Link
          to="/"
          className="mt-3 block rounded-full bg-brand-soft py-4 text-center text-sm font-semibold text-foreground"
        >
          Voltar para início
        </Link>

        {studio?.whatsapp && (
          <a
            href={`https://wa.me/55${studio.whatsapp.replace(/\D/g, "")}`}
            target="_blank"
            rel="noreferrer"
            className="mt-6 flex items-center justify-center gap-2 text-sm font-semibold text-brand"
          >
            <MessageCircle className="h-4 w-4" />
            Falar no WhatsApp
          </a>
        )}

      </div>
    </main>
  );
}
